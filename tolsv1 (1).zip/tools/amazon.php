<?php 
include'anympart/head.php';
include'anympart/sidebar.php' ;
include'datatools/amazon.php';
include'./sec.php'
?>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include'anympart/footer.php' ?>