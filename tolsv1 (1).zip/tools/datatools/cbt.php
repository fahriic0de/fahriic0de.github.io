<?php
$judul=@CBT_Exploit_Scanner;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <form method="POST">
		Site<input type="text" class="form-control text-primary" name="url" placeholder="https://example.com">
		<br><center>
		<input type="submit" value="Scan Exploit Candy CBT" class="btn btn-outline-primary" name="cbtcandy">
		&nbsp;
		<input type="submit" value="Scan Exploit Beesmart CBT" class="btn btn-outline-primary" name="cbtbeesmart">
		</center>
	</form>
</body>
</html>
<?php
function curl($url){
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_HEADER, true);
	$exe = curl_exec($curl);
	$info = curl_getinfo($curl, CURLINFO_HTTP_CODE);
	curl_close($curl);
	return $info;
}
if (isset($_POST['url']) && !empty($_POST['url'])) {
	$filter = htmlspecialchars($_POST['url']);
	if(!preg_match('#^http(s)?://#',$filter)){
		$web = "http://".$filter;
	}
	else {
		$web = $filter;
	}
	$exp5 = $web."/admin/?pg=uplsiswa";
	$exp6 = $web."/x-panel/?pg=banksoal&ac=lihat&id=990";
	$candy = array('/plugins/uploadfile/demo/uploads/demo.html', '/plugins/uploadfile/demo/uploads/upload.php','/admin/filesoal.php','/admin/restore.php','/admin/soal/import_file.php','/admin/ifm.php');
	$beesmart = array('/panel/pages/upload-file.php','/panel/pages/upload-logo.php','/panel/pages/upload_audio.php','/panel/pages/upload_video.php','/panel/pages/upload_gambar.php','/panel/pages/upload-fotosiswa.php','/panel/pages/upload-banner.php','/panel/pages/upload_jawab7.php','/panel/pages/upload_jawab6.php','/panel/pages/upload_jawab5.php','/panel/pages/upload_jawab2.php','/panel/pages/upload_jawab1.php');
	if (isset($_POST['cbtcandy'])) {
		if (curl($web."/admin/login.php") == "200") {
			foreach ($candy as $key) {
				$site = $web.$key;
				if (curl($site) == "200") {
					echo "<br><div class='alert alert-success'> Found : <a href='$site' target='_blank'>$site</a></div><br>";
				}
				else {
					echo "<br><div class='alert alert-danger'> Not Found : $site </div><br>";
				}
			}
			if (curl($exp5) == "302") {
				echo "<br><div class='alert alert-warning'> Vuln : <a href='$exp5' target='_blank'>$exp5</a></div><br>";
			}
			else {
				echo "<br><div class='alert alert-danger'>Not Vuln : $exp5 </div>";
			}
			echo "<br>Tutorial Exploit : <a href='https://ecchiexploit.blogspot.com/search?q=candy+cbt' target='_blank'>Klick Here</a>";
		}
		else if(curl($web."/x-panel/login.php") == "200") {
			if(curl($exp6) == "302"){
				echo "<br><div class='alert alert-success'>Sql Injection With Sqlmap : <a href='$exp6' target='_blank'>$exp6</a><div><br>";
				echo "<br><div class='alert alert-info'> Tutorial : <a href='https://ecchiexploit.blogspot.com/2020/09/sql-injection-in-new-candy-cbt-v28-rev.html' target='_blank'> Klick Here </a></div>";
			}
			else {
				echo "<br><div class='alert alert-danger'>Not Injection : $exp6 </div>";
			}
		}
		else {
			echo "<br><div class='alert alert-danger'>Not Candy CBT </div>";
		}
	}
	else if (isset($_POST['cbtbeesmart'])) {
		if (curl($web."/panel/pages/login.php") == "200") {
			foreach ($beesmart as $key) {
				$site = $web.$key;
				if (curl($site) == "200") {
					echo "<br><div class='alert alert-success'>Found : <a href='$site' target='_blank'>$site</a></div><br>";
				}
				else {
					echo "<br><div class='alert alert-warning'>Not Found : $site </div><br>";
				}
			}
		}
		else {
			echo "<br><div class='alert alert-danger'> Not Beesmart CBT </div>";
		}
	}
}
?>