<?php
$judul=@ClickJacking_Tester;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <center>
<input class="form-control text-warning" id="link" type="text" value="" placeholder="https://onedetermination.com" ><br><br>
<button class="btn btn-outline-primary" id="CJ">Test</button> 
<br>
<br>
<iframe id="iframe" src="about:blank" frameborder="0" width="100%" height="500"></iframe>
   </center>
<script>
function BUGCJKOKMASUKBERITA() {
var link = document.getElementById("link").value;
var iframe = document.getElementById("iframe");
iframe.src = link;
} 
document.addEventListener('DOMContentLoaded', function () {
document.getElementById('CJ').addEventListener('click',
function() {
BUGCJKOKMASUKBERITA();
}
);
});
</script>