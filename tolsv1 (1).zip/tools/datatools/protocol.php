<?php
$judul=@Mass_Add_HTTP_or_HTTPS;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p>
<?php str_replace("_", " ", "$judul");?>
    </p></div>
    <div class="card-body">
      <div class="table-responsive">

<table class="table table-bordered table-striped">
<form action="" method="post">
<label for="url">Choice:</label>
                  <input type="radio" name="choice" value="p" checked>HTTP
                  <input type="radio" name="choice" value="s">HTTPS
                  <div align="center">
Domain: 
<textarea name="site" class="form-control"></textarea><br><input class="btn btn-outline-primary" type="submit" name="submit" value="Submit"><br>
    </div><br>
<?php
    $choice = $_POST["choice"];
    $site=$_POST['site'];
	$explode = explode("\n",$site);
	foreach($explode as $site){
	    if (isset($_POST['submit'])) {
	    if ($choice == "p") {
       echo "http://$site<br>";
      } if ($choice == "s") {
     echo "https://$site<br>";
          }
	        
	    }
}
	?></table>