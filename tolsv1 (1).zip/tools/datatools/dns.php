<?php
$judul=@DNS_LookUp;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          	<form action="" method="post">
			<div class="form-group">
				<input class="form-control text-primary" autocomplete="off" name ="domain" type="text" placeholder="<?php if(isset($_POST['submit'])) { echo($_POST['domain']); }else{echo("onedetermination.com");} ?>" requirerd>
				<br>
	        	<button type="submit" name="submit" class="btn btn-outline-primary">Check</button>
			</div>
		</form>
	</div>


		<?php

			if(isset($_POST['submit']))
					{
						$domain_regex = '/[a-z\d][a-z\-\d\.]+[a-z\d]/i';
						$domain = $_POST['domain'];
						$dns_a = dns_get_record($domain, DNS_A);
						$dns_ns = dns_get_record($domain, DNS_NS);
						$dns_mx = dns_get_record($domain, DNS_MX);
						$dns_soa = dns_get_record($domain, DNS_SOA);
						$dns_txt = dns_get_record($domain, DNS_TXT);
						$dns_aaaa = dns_get_record($domain, DNS_AAAA);
						$dns_all = dns_get_record($domain, DNS_ALL);

		?>
       <div class="card">
<div class="card-header text-center text-muted"> RESULTS </div>
<div class="card-body bg-light text-white rounded-bottom">
<div class="table table-sm table-responsive">
<table class="container-fluid text-nowrap table-hover table-borderless text-dark">
<thead class='thead-light'>
<tr class='text-info'>
					<td class="text-center">Record</td>
					<td class="text-center">Class</td>
					<td class="text-center">TTL</td>
					<td>Details for <?php echo($_POST['domain']); ?></td>
			</thead>
			<tr>
				<td class="vert-align text-center"><h4><span class="label label-primary"><?php echo($dns_a[0]['type']); ?></span></h4></td>
				<td class="vert-align text-center"><?php echo($dns_a[0]['class']); ?></td>
				<td class="vert-align text-center"><?php echo($dns_a[0]['ttl']); ?></td>
				<td>
					<?php 
					foreach($dns_a as $value)
						{
							?>	<h4>
									<?php
										echo($value['ip']);
									?>
								</h4>
							<?php } ?>
				</td>
			</tr>
			<?php $result_aaaa = empty($dns_aaaa); if($result_aaaa != null){ ?>
			<tr class = "warning">
				<td class="vert-align text-center"><h4>AAAA</h4></td>
				<td class="vert-align text-center">/</td>
				<td class="vert-align text-center">/</td>
				<td><h4>No AAAA record for this server (IPV6)</h4></td>
			</tr>
			<?php } else { ?>
			<tr>
				<td class="vert-align text-center"><h4><span class="label label-info"><?php echo($dns_aaaa[0]['type']); ?><?php echo($result_aaaa); ?></span></h4></td>
				<td class="vert-align text-center"><?php echo($dns_aaaa[0]['class']); ?></td>
				<td class="vert-align text-center"><?php echo($dns_aaaa[0]['ttl']); ?></td>
				<td>
					<?php 
					foreach($dns_aaaa as $value)
						{
							?><h4>
								<?php  echo($value['ipv6']); ?>
							</h4>
							<?php } ?>
				</td>
			</tr>
			<?php } ?>
			<tr>
				<td class="vert-align text-center"><h4><span class="label label-success"><?php echo($dns_ns[0]['type']); ?></span></h4></td>
				<td class="vert-align text-center"><?php echo($dns_ns[0]['class']); ?></td>
				<td class="vert-align text-center"><?php echo($dns_ns[0]['ttl']); ?></td>
				<td>
					<?php 
					foreach($dns_ns as $value)
						{
							?><h4>
								<?php  echo($value['target']); ?>
								(<?php echo(gethostbyname($value['target'])) ?>)
							</h4>
							<?php } ?>
				</td>
			</tr>
			<tr>
				<td class="vert-align text-center"><h4><span class="label label-danger"><?php echo($dns_mx[0]['type']); ?></span></h4></td>
				<td class="vert-align text-center"><?php echo($dns_mx[0]['class']); ?></td>
				<td class="vert-align text-center"><?php echo($dns_mx[0]['ttl']); ?></td>
				<td>
					<?php 
					foreach($dns_mx as $value)
						{
							?><h4>
								[<?php  echo($value['pri']); ?>] 
								<?php  echo($value['target']); ?>
								(<?php echo(gethostbyname($value['target'])) ?>)
							</h4>
							<?php } ?>
				</td>
			</tr>
			<tr>
				<td class="vert-align text-center"><h4><span class="label label-warning"><?php echo($dns_soa[0]['type']); ?></span></h4></td>
				<td class="vert-align text-center"><?php echo($dns_soa[0]['class']); ?></td>
				<td class="vert-align text-center"><?php echo($dns_soa[0]['ttl']); ?></td>
				<td>
						<h4>Email : <?php $email = explode(".", $dns_soa[0]['rname']); echo($email[0].'@'.$email[1].'.'.$email[2]); ?></h4>
						<h4>Serial : <?php echo($dns_soa[0]['serial']); ?></h4>
						<h4>Refresh : <?php echo($dns_soa[0]['refresh']); ?></h4>
						<h4>Retry : <?php echo($dns_soa[0]['retry']); ?></h4>
						<h4>Expire : <?php echo($dns_soa[0]['expire']); ?></h4>
						<h4>Minimum TTL : <?php echo($dns_soa[0]['minimum-ttl']); ?></h4>
				</td>
			</tr>
			<tr>
				<td class="vert-align text-center"><h4><span class="label label-default"><?php echo($dns_txt[0]['type']); ?></span></h4></td>
				<td class="vert-align text-center"><?php echo($dns_txt[0]['class']); ?></td>
				<td class="vert-align text-center"><?php echo($dns_txt[0]['ttl']); ?></td>
				<td>
						<h4><?php echo($dns_txt[0]['txt']); ?></h4>
				</td>
			</tr>
		</table>

	</div>

<?php
					}
?>    </div> <!-- /container -->
  </body>