<?php
$judul=@URL_List_Cleaner;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
         
        <center>
        <form id="concatenate">
    	   <textarea class="form-control" id="linklist" rows="15" cols="auto"></textarea><br><br>
    	</form>
    	<div id="commands">
            <button id="root" class="btn btn-outline-primary">Trim Root</button>&nbsp;&nbsp;
    		<button id="subfolder" class="btn btn-outline-primary">Trim Subfolder</button>&nbsp;&nbsp;
    		<button class="btn btn-outline-warning" onclick="myFunction()">Copy Result</button>&nbsp;&nbsp;
    		<button class="btn btn-outline-danger" onclick="eraseText()">Reset Result</button>&nbsp;&nbsp;
    		<button id="removehttp" class="btn btn-outline-primary">Remove http/s, www</button>&nbsp;&nbsp;
    		<button id="domains" class="btn btn-outline-primary">Remove Duplicate Domain</button>&nbsp;&nbsp;
    		<button id="urls" class="btn btn-outline-primary">Remove Duplicate URL</button>
        </div>
        </center>
<script>

    function myFunction() {
      var copyText = document.getElementById("linklist");
    
      copyText.select();
      copyText.setSelectionRange(0, 99999);
    
      document.execCommand("copy");
    
      Swal.fire({
					  	title: 'Berhasil',
					  	text: 'Text Berhasil Disalin',
					})
    }
    
    function eraseText() {
        document.getElementById("linklist").value = "";
    }

</script>
<script>
    ! function(t, e) { "use strict"; e(function() {
        function t(t) {
            var i = e("#linklist").val().trim().split("\n"),
                n = [];
            if ("root" == t)
                for (var a = 0; a < i.length; a++) {
                    var o = i[a].trim(),
                        l = o.match(/^(.*?)?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);
                    if (null != l) n.push(l[1] + "://" + l[2] + "/");
                    else {
                        var l = o.match(/^([^\/?#]+)(?:[\/?#]|$)/i);
                        null != l && n.push(l[1] + "/")
                    } } else if ("subfolder" == t)
                        for (var a = 0; a < i.length; a++) {
                            var r = i[a].trim().split(/[?#]/)[0],
                                d = r.lastIndexOf("/");
                            n.push(-1 != d ? d > 8 ? r.substr(0, r.lastIndexOf("/") + 1) : r : r)
                    } else if ("urls" == t)
                        for (var a = 0; a < i.length; a++) {
                            var o = i[a].trim(); - 1 == n.indexOf(o) && n.push(o)
                    } else if ("domains" == t)
                        for (var s = [], a = 0; a < i.length; a++) {
                            var o = i[a].trim(),
                                l = o.match(/^(.*?)?\:\/\/([^\/?#]+)(?:[\/?#]|$)/i);
                            if (null != l) - 1 == s.indexOf(l[2]) && (s.push(l[2]), n.push(o));
                            else {
                                var l = o.match(/^([^\/?#]+)(?:[\/?#]|$)/i);
                                null != l && -1 == s.indexOf(l[1]) && (s.push(l[1]), n.push(o))
                    } } else if ("removehttp" == t)
                        for (var f = ["uk", "au", "mx", "nz"], u = ["ca", "com", "net", "org", "edu", "gov", "id", "tech", "pl", "ninja", "co", "com", "pro", "it", "org", "de", "club", "net", "biz", "edu", "name", "aero", "asia", "cat", "coop", "int", "jobs", "mil", "tel", "museum", "travel", "or.id", "net.id", "web.id", "desa.id", "xyz", "ga", "ml", "io", "blue", "com", "sg", "tv", "tech", "news", "toys", "mobi", "bz", "cc", "site", "online", "shop", "ws", "me", "pw", "events", "promo", "photography", "today", "shoes", "camera", "fun", "store", "date", "pictures", "win", "com.lb2", "art", "academy", "website", "ninja", "reviews", "dance", "futbol", "wiki", "pink", "red", "kim", "press", "top", "center", "link", "management", "watch", "technology", "bike", "clothing", "guru", "holdings", "plumbing", "singles", "ventures", "estate", "equipment", "gallery", "kitchen", "directory", "contractors", "tips", "enterprises", "diamonds", "graphics", "lighting", "land", "cloud", "trade", "company", "shiksha", "space", "work", "expert", "media", "computer", "voyage", "construction", "careers", "domains", "email", "consulting", "investments", "cash", "town", "university", "reisen", "lease", "associates", "gripe", "exchange", "engineering", "capital", "services", "opr", "vision", "report", "fish", "supply", "supplies", "moda", "rest", "webcam", "bid", "productions", "partners", "dating", "condos", "properties", "maison", "tienda", "villas", "vacations", "rentals", "flight", "cruises", "exposed", "foundation", "works", "cool", "zone", "cheap", "boutique", "bergains", "agency", "buzz", "uno", "farm", "viajes", "codes", "holiday", "marketing", "international", "solar", "house", "florist", "coffe", "institute", "repair", "education", "camp", "training", "support", "solutions", "limo", "cab", "builders", "menu", "recipes", "systems", "uno", "academy", "accountants", "actor", "agency", "airforce", "apartments", "app", "army", "associates", "attorney", "auction", "band", "bargains", "bike", "bingo", "biz", "boutique", "builders", "business", "ca", "cab", "cafe", "camera", "camp", "capital", "cards", "care", "careers", "cash", "casino", "catering", "cc", "center", "chat", "charity", "cheap", "church", "city", "claims", "cleaning", "clinic", "clothing", "club", "co", "co.in", "co.nz", "co.uk", "coach", "codes", "coffee", "com", "com.mx", "community", "company", "computer", "condos", "construction", "consulting", "contractors", "cool", "coupons", "credit", "creditcard", "cruises", "dance", "dating", "deals", "degree", "delivery", "democrat", "dental", "dentist", "design", "dev", "diamonds", "digital", "direct", "directory", "discount", "dog", "domains", "education", "email", "energy", "engineer", "engineering", "enterprises", "equipment", "estate", "events", "exchange", "expert", "exposed", "express", "fail", "family", "fan", "farm", "finance", "financial", "fish", "fitness", "flights", "florist", "football", "forsale", "foundation", "fr", "fun", "fund", "furniture", "futbol", "fyi", "gallery", "games", "gifts", "gives", "glass", "gmbh", "gold", "golf", "graphics", "gratis", "gripe", "group", "guide", "guru", "haus", "healthcare", "hockey", "holdings", "holiday", "hospital", "host", "house", "how", "immo", "immobilien", "in", "industries", "info", "ink", "institute", "insure", "international", "investments", "io", "irish", "jewelry", "jetzt", "jp", "kaufen", "kitchen", "land", "lawyer", "lease", "legal", "life", "lighting", "limited", "limo", "live", "llc", "loans", "ltd", "maison", "management", "market", "marketing", "mba", "me", "media", "memorial", "moda", "money", "mortgage", "movie", "mx", "navy", "net", "network", "news", "ninja", "online", "org", "page", "partners", "parts", "photography", "photos", "pictures", "pizza", "plumbing", "plus", "press", "productions", "properties", "pub", "pw", "recipes", "rehab", "reise", "reisen", "rentals", "repair", "report", "republican", "restaurant", "reviews", "rocks", "rip", "run", "sale", "salon", "sarl", "school", "schule", "services", "shoes", "shopping", "show", "singles", "site", "soccer", "social", "software", "solar", "solutions", "soy", "space", "store", "studio", "style", "supplies", "supply", "support", "surgery", "systems", "tax", "taxi", "team", "tech", "technology", "tennis", "theater", "tienda", "tips", "tires", "today", "tools", "tours", "town", "toys", "training", "university", "us", "vacations", "ventures", "vet", "viajes", "video", "villas", "vin", "vision", "voyage", "watch", "website", "wiki", "wine", "works", "world", "wtf", "zone", "new", "uk", "art", "bar", "best", "bio", "black", "blog", "buzz", "blue", "ceo", "doctor", "earth", "eco", "fans", "global", "green", "health", "icu", "love", "luxury", "mobi", "ooo", "promo", "realty", "red", "rest", "ski", "tube", "uno", "xyz", "place", "ac", "ad", "ae", "af", "ag", "ai", "al", "am", "an", "ao", "aq", "ar", "as", "at", "au", "aw", "ax", "az", "ba", "bb", "bd", "be", "bf", "bg", "bh", "bi", "bj", "bm", "bn", "bo", "bq", "br", "bs", "bt", "bv", "bw", "by", "bz", "ca", "cc", "cd", "cf", "cg", "ch", "ci", "ck", "cl", "cm", "cn", "co", "cr", "cu", "cv", "cw", "cx", "cy", "cz", "de", "dj", "dk", "dm", "do", "dz", "ec", "ee", "eg", "eh", "er", "es", "et", "eu", "fi", "fj", "fk", "fm", "fo", "fr", "ga", "gb", "gd", "ge", "gf", "gg", "gh", "gi", "gl", "gm", "gn", "gp", "gq", "gr", "gs", "gt", "gu", "gw", "gy", "hk", "hm", "hn", "hr", "ht", "hu", "id", "ie", "il", "im", "in", "io", "iq", "ir", "is", "it", "je", "jm", "jo", "jp", "ke", "kg", "kh", "ki", "km", "kn", "kp", "kr", "kw", "ky", "kz", "la", "lb", "lc", "li", "lk", "lr", "ls", "lt", "lu", "lv", "ly", "ma", "mc", "md", "me", "mg", "mh", "mk", "ml", "mm", "mn", "mo", "mp", "mq", "mr", "ms", "mt", "mu", "mv", "mw", "mx", "my", "mz", "na", "nc", "ne", "nf", "ng", "ni", "nl", "no", "np", "nr", "nu", "nz", "om", "pa", "pe", "pf", "pg", "ph", "pk", "pl", "pm", "pn", "pr", "ps", "pt", "pw", "py", "qa", "re", "ro", "rs", "ru", "rw", "sa", "sb", "sc", "sd", "se", "sg", "sh", "si", "sj", "sk", "sl", "sm", "sn", "so", "sr", "ss", "st", "su", "sv", "sx", "sy", "sz", "tc", "td", "tf", "tg", "th", "tj", "tk", "tl", "tm", "tn", "to", "tp", "tr", "tt", "tv", "tw", "tz", "ua", "ug", "uk", "us", "uy", "uz", "va", "vc", "ve", "vg", "vi", "vn", "vu", "wf", "ws", "ye", "yt", "za", "zm", "zw", "com", "pro", "it", "org", "de", "club", "net", "biz", "edu", "name", "aero", "asia", "cat", "coop", "int", "jobs", "mil", "tel", "museum", "travel", "or.id", "net.id", "web.id", "desa.id", "xyz", "ga", "ml", "io", "blue", "com", "sg", "tv", "tech", "news", "toys", "mobi", "bz", "cc", "site", "online", "shop", "ws", "me", "pw", "events", "promo", "photography", "today", "shoes", "camera", "fun", "store", "date", "pictures", "win", "com.lb2", "art", "academy", "website", "ninja", "reviews", "dance", "futbol", "wiki", "pink", "red", "kim", "press", "top", "center", "link", "management", "watch", "technology", "bike", "clothing", "guru", "holdings", "plumbing", "singles", "ventures", "estate", "equipment", "gallery", "kitchen", "directory", "contractors", "tips", "enterprises", "diamonds", "graphics", "lighting", "land", "cloud", "trade", "company", "shiksha", "space", "work", "expert", "media", "computer", "voyage", "construction", "careers", "domains", "email", "consulting", "investments", "cash", "town", "university", "reisen", "lease", "associates", "gripe", "exchange", "engineering", "capital", "services", "opr", "vision", "report", "fish", "supply", "supplies", "moda", "rest", "webcam", "bid", "productions", "partners", "dating", "condos", "properties", "maison", "tienda", "villas", "vacations", "rentals", "flight", "cruises", "exposed", "foundation", "works", "cool", "zone", "cheap", "boutique", "bergains", "agency", "buzz", "uno", "farm", "viajes", "codes", "holiday", "marketing", "international", "solar", "house", "florist", "coffe", "institute", "repair", "education", "camp", "training", "support", "solutions", "limo", "cab", "builders", "menu", "recipes", "systems", "uno", "academy", "accountants", "actor", "agency", "airforce", "apartments", "app", "army", "associates", "attorney", "auction", "band", "bargains", "bike", "bingo", "biz", "boutique", "builders", "business", "ca", "cab", "cafe", "camera", "camp", "capital", "cards", "care", "careers", "cash", "casino", "catering", "cc", "center", "chat", "charity", "cheap", "church", "city", "claims", "cleaning", "clinic", "clothing", "club", "co", "co.in", "co.nz", "co.uk", "coach", "codes", "coffee", "com", "com.mx", "community", "company", "computer", "condos", "construction", "consulting", "contractors", "cool", "coupons", "credit", "creditcard", "cruises", "dance", "dating", "deals", "degree", "delivery", "democrat", "dental", "dentist", "design", "dev", "diamonds", "digital", "direct", "directory", "discount", "dog", "domains", "education", "email", "energy", "engineer", "engineering", "enterprises", "equipment", "estate", "events", "exchange", "expert", "exposed", "express", "fail", "family", "fan", "farm", "finance", "financial", "fish", "fitness", "flights", "florist", "football", "forsale", "foundation", "fr", "fun", "fund", "furniture", "futbol", "fyi", "gallery", "games", "gifts", "gives", "glass", "gmbh", "gold", "golf", "graphics", "gratis", "gripe", "group", "guide", "guru", "haus", "healthcare", "hockey", "holdings", "holiday", "hospital", "host", "house", "how", "immo", "immobilien", "in", "industries", "info", "ink", "institute", "insure", "international", "investments", "io", "irish", "jewelry", "jetzt", "jp", "kaufen", "kitchen", "land", "lawyer", "lease", "legal", "life", "lighting", "limited", "limo", "live", "llc", "loans", "ltd", "maison", "management", "market", "marketing", "mba", "me", "media", "memorial", "moda", "money", "mortgage", "movie", "mx", "navy", "net", "network", "news", "ninja", "online", "org", "page", "partners", "parts", "photography", "photos", "pictures", "pizza", "plumbing", "plus", "press", "productions", "properties", "pub", "pw", "recipes", "rehab", "reise", "reisen", "rentals", "repair", "report", "republican", "restaurant", "reviews", "rocks", "rip", "run", "sale", "salon", "sarl", "school", "schule", "services", "shoes", "shopping", "show", "singles", "site", "soccer", "social", "software", "solar", "solutions", "soy", "space", "store", "studio", "style", "supplies", "supply", "support", "surgery", "systems", "tax", "taxi", "team", "tech", "technology", "tennis", "theater", "tienda", "tips", "tires", "today", "tools", "tours", "town", "toys", "training", "university", "us", "vacations", "ventures", "vet", "viajes", "video", "villas", "vin", "vision", "voyage", "watch", "website", "wiki", "wine", "works", "world", "wtf", "zone", "new", "uk", "art", "bar", "best", "bio", "black", "blog", "buzz", "blue", "ceo", "doctor", "earth", "eco", "fans", "global", "green", "health", "icu", "love", "luxury", "mobi", "ooo", "promo", "realty", "red", "rest", "ski", "tube", "uno", "xyz", "place", "name", "aaa.pro", "aca.pro", "academy", "site:", "accountant", "accountants", "acct.pro", "actor", "adult", "adv.br", "ae.org", "agency", "airforce", "amsterdam", "apartments", "app", "archi", "army", "arq.br", "art", "art.br", "asia", "associates", "attorney", "auction", "audio", "auto", "avocat.pro", "band", "bar", "bar.pro", "bargains", "beer", "berlin", "best", "bet", "bid", "bike", "bingo", "bio", "biz", "black", "blackfriday", "blog", "blog.br", "blue", "boutique", "br.com", "build", "builders", "business", "buzz", "bz", "ca", "cab", "cafe", "cam", "camera", "camp", "capetown", "capital", "car", "cards", "care", "career", "careers", "cars", "casa", "cash", "casino", "catering", "cc", "center", "chat", "cheap", "christmas", "church", "city", "cl", "claims", "cleaning", "click", "clinic", "clothing", "cloud", "club", "cn", "cn.com", "co", "co.com", "co.de", "co.in", "co.nz", "co.uk", "co.za", "coach", "codes", "coffee", "college", "com", "com.au", "com.br", "com.cn", "com.co", "com.de", "com.ec", "com.mx", "com.ru", "com.sc", "community", "company", "computer", "condos", "construction", "consulting", "contractors", "cooking", "cool", "country", "coupons", "courses", "cpa.pro", "credit", "creditcard", "cricket", "cruises", "cymru", "dance", "date", "dating", "de", "de.com", "deals", "degree", "delivery", "democrat", "dental", "dentist", "desi", "design", "dev", "diamonds", "diet", "digital", "direct", "directory", "discount", "doctor", "dog", "domains", "download", "durban", "earth", "ec", "eco", "eco.br", "education", "email", "energy", "eng.br", "eng.pro", "engineer", "engineering", "enterprises", "equipment", "es", "estate", "eu", "eu.com", "events", "exchange", "expert", "exposed", "express", "fail", "faith", "family", "fans", "farm", "fashion", "feedback", "fin.ec", "finance", "financial", "firm.in", "fish", "fishing", "fit", "fitness", "flights", "florist", "flowers", "fm", "football", "forsale", "foundation", "fr", "fun", "fund", "furniture", "futbol", "fyi", "gallery", "game", "games", "garden", "gb.net", "gdn", "gen.in", "gift", "gifts", "gives", "glass", "global", "gmbh", "gold", "golf", "gr.com", "graphics", "gratis", "green", "gripe", "group", "guide", "guitars", "guru", "haus", "health", "healthcare", "help", "hiphop", "hockey", "holdings", "holiday", "homes", "horse", "hospital", "host", "hosting", "house", "how", "hu.com", "icu", "id", "immo", "immobilien", "in", "in.net", "ind.br", "ind.in", "industries", "info", "info.ec", "ink", "institute", "insure", "international", "investments", "io", "irish", "jetzt", "jewelry", "jobs", "joburg", "jpn.com", "juegos", "jur.pro", "kaufen", "kim", "kitchen", "kiwi", "la", "land", "lat", "law", "law.pro", "lawyer", "lease", "legal", "lgbt", "life", "lighting", "limited", "limo", "link", "live", "loan", "loans", "lol", "london", "lotto", "love", "ltd", "ltda", "luxury", "maison", "management", "market", "marketing", "markets", "mba", "me", "me.uk", "med.ec", "med.pro", "media", "memorial", "men", "menu", "miami", "mn", "mobi", "moda", "mom", "money", "mortgage", "mus.br", "mx", "nagoya", "navy", "net", "net.au", "net.br", "net.cn", "net.co", "net.ec", "net.in", "net.nz", "net.ru", "net.sc", "network", "news", "ngo", "ninja", "nl", "no.com", "nom.co", "nyc", "nz", "one", "ong", "online", "ooo", "org", "org.cn", "org.in", "org.mx", "org.nz", "org.ru", "org.sc", "org.uk", "page", "partners", "parts", "party", "pet", "ph", "photo", "photography", "photos", "physio", "pics", "pictures", "pink", "pizza", "place", "plumbing", "plus", "poker", "porn", "press", "pro", "pro.br", "pro.ec", "productions", "promo", "properties", "property", "protection", "pub", "pw", "qc.com", "quebec", "racing", "recht.pro", "recipes", "red", "rehab", "reisen", "rent", "rentals", "repair", "report", "republican", "rest", "restaurant", "review", "reviews", "rip", "rocks", "rodeo", "ru", "ru.com", "run", "sa.com", "sale", "salon", "sarl", "sc", "school", "schule", "science", "scot", "se.com", "se.net", "security", "services", "sex", "sexy", "shiksha", "shoes", "shop", "shopping", "show", "singles", "site", "ski", "soccer", "social", "software", "solar", "solutions", "soy", "space", "srl", "store", "stream", "studio", "study", "style", "supplies", "supply", "support", "surf", "surgery", "sx", "systems", "tattoo", "tax", "taxi", "team", "tech", "technology", "tel", "tennis", "theater", "theatre", "tienda", "tips", "tires", "today", "tokyo", "tools", "top", "tours", "town", "toys", "trade", "trading", "training", "travel", "tube", "tv", "uk", "uk.com", "uk.net", "university", "uno", "us", "us.com", "vacations", "vc", "vegas", "ventures", "vet", "viajes", "video", "villas", "vin", "vip", "vision", "vodka", "vote", "voto", "voyage", "wales", "wang", "watch", "webcam", "website", "wedding", "wiki", "wiki.br", "win", "wine", "work", "works", "world", "ws", "wtf", "xxx", "xyz", "yoga", "za.com", "zone", "орг", "شبكة", "भारत", "संगठन", "中文网", "在线", "机构", "移动"], a = 0; a < i.length; a++) {
                        var o = i[a].trim().replace("http://", "").replace("https://", "").replace("www.", ""),
                            l = o.match(/^([^\/?#]+)(?:[\/?#]|$)/i),
                            c = l[1].split("."),
                            p = c.length;
                        if (c.length > 2) {
                            var h = null; - 1 != f.indexOf(c[p - 1]) ? h = [c[p - 3], c[p - 2], c[p - 1]].join(".") : -1 != u.indexOf(c[p - 1]) && (h = [c[p - 2], c[p - 1]].join(".")), null != h && n.push(o.substr(o.indexOf(h), o.length))
                        } else n.push(o)
                    } else if ("addhttp" == t)
                        for (var a = 0; a < i.length; a++) {
                            var o = i[a].trim(),
                                l = o.match(/(?:http[s]\:\/\/)(.?)\.(?=[^\/]\..{2,5})/i);
                            n.push(null != l ? 0 == l[0].indexOf("http") && "www" == l[1] ? o : 0 == l[0].indexOf("http") ? o : "http://" + o : 0 == o.indexOf("http") ? o : "http://" + o)
                    } e("#linklist").val(n.join("\n")) }

            if ("undefined" != typeof ZeroClipboard) {
                var i = e(".copybutton"),
                    n = new ZeroClipboard(i),
                    a = e("#linklist");
                n.on("ready", function() {
                    n.on("copy", function(t) {
                        var e = t.target.id,
                            i = t.clipboardData;
                        "singlecopy" === e && a.length && i.setData("text/plain", a.val()), "multicopy" === e && multiPasswordCopy.length && i.setData("text/plain", multiPasswordCopy.val())
                    }), n.on("aftercopy", function(t) {
                        var i = e("#" + t.target.id);
                        if ("undefined" != typeof t.target.dataset.copied && "undefined" != typeof t.target.dataset.label && "undefined" != typeof t.target.id) {
                            var n = t.target.dataset.label,
                                a = t.target.dataset.copied;
                            i.attr("data-label", a).one("load", function() {
                                setTimeout(function() {
                                    i.attr("data-label", n)
                                }, 3e3)
                            }).trigger("load")
                        }
                    })
                }), n.on("error", function(t) {
                i.hide(), console.log(t.message), n.destroy()
                })
            } else console.log("ZeroClipboard not loaded");
            e("body").on("click", "#root", function() {
                t(e(this).attr("id"))
            }), e("body").on("click", "#subfolder", function() {
                t(e(this).attr("id"))
            }), e("body").on("click", "#urls", function() {
                t(e(this).attr("id"))
            }), e("body").on("click", "#domains", function() {
                t(e(this).attr("id"))
            }), e("body").on("click", "#removehttp", function() {
                t(e(this).attr("id"))
            }), e("body").on("click", "#addhttp", function() {
                t(e(this).attr("id"))
            })
        })
    }(document, jQuery);

</script>