<?php
$judul=@Tracking_Paket;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><?php echo str_replace("_", " ", "$judul"); ?><button type="button" class="btn btn-primary float-right" id="btn_refresh"><i class="fas fa-sync"></i> Refresh</button>
    </div>
    <div class="card-body">
      <div class="table-responsive">

        <link rel="stylesheet" href="assets/sweetalert2/sweetalert2.min.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/datatables/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="assets/datatables/css/select.bootstrap4.min.css">
        <link rel="stylesheet" href="assets/datatables/css/buttons.bootstrap4.min.css">
        <link rel="stylesheet" href="assets/select2/css/select2.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css">
        <script src="https://kit.fontawesome.com/7a4dfbbce0.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="assets/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
                            <div class="row">
                                <div class="col-lg-6 col-sm-12 col-md-12 form-group row">
                                    <label class="col-4 col-form-label text-danger">Nomor Resi </label>
                                    <div class="col-8">
                                        <input type="text" class="form-control" name="waybill" id="waybill" placeholder="Nomor Resi">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-sm-12 col-md-12 form-group row">
                                    <label class="col-4 col-form-label">Kurir</label>
                                    <div class="col-8">
                                        <select name='courier' class=' form-control text-danger' id="courier">
                                            <option class="text-warning" value="">-- Pilih --</option>
                                            <option class="text-warning" value="jne">JNE</option>
                                            <option class="text-warning" value="pos">POS Indonesia</option>
                                            <option class="text-warning" value="tiki">TIKI</option>
                                            <option class="text-warning" value="wahana">WAHANA</option>
                                            <option class="text-warning" value="sicepat">SICEPAT</option>
                                            <option class="text-warning" value="ninja">Ninja Xpress</option>
                                            <option class="text-warning" value="lion">Lion Parcel</option>
                                            <option class="text-warning" value="jet">JET Express (JET)</option>
                                            <option class="text-warning" value="pahala">Pahala Kencana Express (PAHALA)</option>
                                            <option class="text-warning" value="sap">SAP Express (SAP)</option>
                                            <option class="text-warning" value="star">Star Cargo (STAR)</option>
                                            <option class="text-warning" value="pcp">Priority Cargo and Package (PCP)</option>
                                            <option class="text-warning" value="esl">Eka Sari Lorena (ESL)</option>
                                            <option class="text-warning" value="rpx">RPX Holding (RPX)</option>
                                            <option class="text-warning" value="pandu">Pandu Logistics (PANDU)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                            	<div class="col-md-12 form-group row">
                            		<div class="col-md-12">
                            			<button type="button" class="btn btn-info float-right mr-4" id="btn_submit"><i class="fas fa-search"></i> Track</button>
                            		</div>
                            	</div>
                            </div>
                        <!-- </form> -->
                    </div>
                </div>

				<div id="table-tracking">
					
				</div>
            </div>
        </div>

        <script type="text/javascript" src="assets/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="assets/select2/js/select2.min.js"></script>
        <script type="text/javascript" src="assets/sweetalert2/sweetalert2.min.js"></script>
        
        <!-- Data tables -->
        <script type="text/javascript" src="assets/datatables/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="assets/datatables/js/dataTables.bootstrap4.min.js"></script>
        <!-- Datepicker -->
        <script type="text/javascript" src="assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>


        <!-- JAVASCRIPT -->
        <script type="text/javascript">
            $(function() {
    ajax_cities()
    ajax_kota()
});

function ajax_cities () {
    $.ajax({
        url: "../API/local_api.php",
        type: "GET",
        dataType: "JSON",
        crossDomain: true,
        success: function (r) {
            var html = ''

            if(r.status){
                var result = r.data
                result.forEach( function(value, index) {
                    html += '<tr>'+
                                '<td scope="row">'+ (index+1) +'</td>' +
                                '<td>'+ value.city_id +'</td>' +
                                '<td>'+ value.city_name +'</td>' +
                                '<td>'+ value.type +'</td>' +
                                '<td>'+ value.province +'</td>' +
                                '<td>'+ value.postal_code +'</td>' +
                            '</tr>'
                });

                fill_table(html, '#tb_cities');
            }else{
                alert(r.pesan);
            }
        }
    });
}

function ajax_kota () {
    $.ajax({
        url: "https://api.banghasan.com/sholat/format/json/kota",
        type: "GET",
        dataType: "JSON",
        crossDomain: true,
        success: function (r) {

            var html = ''

            if(r.status){
                var result = r.kota
                result.forEach( function(value, index) {
                    html += '<tr>'+
                                '<td scope="row">'+ (index+1) +'</td>' +
                                '<td>'+ value.id +'</td>' +
                                '<td>'+ value.nama +'</td>' +
                            '</tr>'
                });

                // $('#tb_kota').find('tbody').empty();

                fill_table(html, '#tb_kota');
            }else{
                alert(r.pesan);
            }
        }
    });
}

function fill_table(html_string, selector){
    $(selector).find('tbody').html(html_string);
    $(selector).dataTable({
        processing: true,
        searching: true,
    });
}

function formatMoney(number, decPlaces, decSep, thouSep) {
    decPlaces   = isNaN(decPlaces = Math.abs(decPlaces)) ? 2 : decPlaces,
    decSep      = typeof decSep === "undefined" ? "." : decSep;
    thouSep     = typeof thouSep === "undefined" ? "," : thouSep;
    var sign    = number < 0 ? "-" : "";
    var i = String(parseInt(number = Math.abs(Number(number) || 0).toFixed(decPlaces)));
    var j = (j = i.length) > 3 ? j % 3 : 0;

    return sign +
        (j ? i.substr(0, j) + thouSep : "") +
        i.substr(j).replace(/(\decSep{3})(?=\decSep)/g, "$1" + thouSep) +
        (decPlaces ? decSep + Math.abs(number - i).toFixed(decPlaces).slice(2) : "");
}

function GetFormattedDate(date) {
    var todayTime   = new Date(date);
    var monthEng    = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    var month       = (todayTime.getMonth());
    var day         = (todayTime.getDate());
    var year        = (todayTime.getFullYear());
    return day + " " + monthEng[month] + " " + year;
}

        </script>
        <script type="text/javascript">

            $(function() {
                opt_kota()
                $("#tanggal").datepicker({
	                startView: 0,
	                minViewMode: 0,
	                autoclose: true,
	            });

                // $('.select2').select2()

                $('#btn_refresh').on('click', function () {
                    onClear()
                })

                $('#btn_submit').on('click', function () {
                    cari()
                })
            });

            function opt_kota () {
                $.ajax({
                    url: "../API/local_api.php",
                    type: "GET",
                    dataType: "JSON",
                    crossDomain: true,
                    success: function (r) {
                        var html = ''

                        if(r.status){
                            var result = r.data
                                        
                            result.forEach( function(value, index) {
                                html += `<option class="text-warning" value="`+ value.city_id +`">`+ value.city_name +`</option>`
                            });


                            $('#origin').append(html);
                            $('#destination').append(html);
                        }else{
                            Swal.fire({
                                type: 'error',
                                title: 'Oops...',
                                text: r.pesan[0],
                            })
                        }
                    }
                });
            }

            function onClear () {
                $('#origin').val('')
                $('#courier').val('')
                $('#destination').val('')

                $('#weight').val('')
				$('#table-ongkir').empty();
            }

            function cari () {
                if ($('#origin').val() != '' && $('#courier').val() != '' && $('#destination').val() != '' && $('#weight').val() != '') {
                    $.ajax({
                        url: "../API/ongkir_api.php",
                        type: "POST",
                        dataType: "JSON",
                        crossDomain: true,
                        data: {
                            weight: $('#weight').val(),
                            origin: $('#origin').val(),
                            destination: $('#destination').val(),
                            courier: $('#courier').val(),

                        },
                        success: function (r) {
                            var html = ''
                            var tr = ''

                            if(r.status){
                                var data    = r.data
                                var costs   = data[0].costs
                                
                                costs.forEach( function(v, index) {
                                    tr += '<tr>' +
                                            '<td scope="row" class="text-center">'+ (index + 1) +'</td>' +
                                            '<td scope="row">'+ v.service +'</td>' +
                                            '<td scope="row">'+ v.description +'</td>' +
                                            '<td scope="row">'+ v.cost[0].etd +' Hari</td>' +
                                            '<td scope="row" class="text-right">Rp. '+ formatMoney(v.cost[0].value) +'</td>' +
                                        '</tr>';
                                });

                                html += '<div class="card mt-5 mb-5">' +
                                        '<div class="card-header">' +
                                            '<b>Ongkos Kirim Kurir ' + $('#courier option:selected').text() + '</b>' +
                                        '</div>' +
                                        '<div class="card-body table-responsive">' +
                                            '<table class="table table-striped table-hover" id="tb_jasa_ongkir">' +
                                                '<thead>' +
                                                    '<tr>' +
                                                      '<th scope="col">No</th>' +
                                                      '<th scope="col">Service</th>' +
                                                      '<th scope="col">Deskripsi</th>' +
                                                      '<th scope="col">Rentang Waktu</th>' +
                                                      '<th scope="col">Harga</th>' +
                                                    '</tr>' +
                                                '</thead>' +
                                                '<tbody>' +
                                                    tr +
                                                '</tbody>' +
                                            '</table>' +
                                        '</div>' +
                                    '</div>';


                                $('#table-ongkir').empty();
                                $('#table-ongkir').append(html);
                                $('#tb_jasa_ongkir').dataTable();
                            }else{
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: r.pesan,
                                })
                            }
                        }
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Silahkan lengkapi Data diatas!',
                    })
                }
            }

        </script>