<?php
$judul=@CBT_Exploit_Scanner;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<div class="container">
<div class="row">
  <div class="col-md-6">
  	<h3>Text</h3>
  	<textarea id="codearea" class="form-control vertical" rows="15"></textarea>
  	<p class="text-danger"><strong>Note : </strong> List harus perline (remove duplicates, Line kosong, Spasi, Karakter lain selain huruf/angka) Pakai <a href="?tools=Remover" target="_blank">Remover</a> Sebelumnya</p>
  	<button type="button"  class="btn btn-primary btn-convert btn-sm" title="convert"><span class="fas fa-chevron-right"> Convert</span></button>
  	
  	
  	    <button type="button" class="btn btn-danger btn-clear-all btn-sm" title="clean all"><span class="fas fa-trash"> Clear All</span></button>
  	<br><br><br>
    <p class="notif">quotes</p>
    <div class="options">
      <div class="row" style="margin-left:0; margin-right:0;">
        <div class="btn-group" data-toggle="buttons-radio">
          <div class="col-xs-12 col-sm-6">
            <button type="button" id="double" class="btn btn-primary btn-sm active block ">Double</button>
          </div>
          <div class="col-xs-12 col-sm-6">
            <button type="button" id="single" class="btn btn-primary btn-sm block">Single</button>
          </div>
        </div>
      </div>
    </div>
           <br>               
    <p class="notif">numbers in quotes?</p>
    <div class="options">
      <div class="row" style="margin-left:0; margin-right:0;">
        <div class="btn-group" data-toggle="buttons-radio">
          <div class="col-xs-12 col-sm-6">
            <button type="button" id="notwithQ" class="btn btn-primary btn-sm active block ">No</button>
          </div>
          <div class="col-xs-12 col-sm-6">
            <button type="button" id="withQ" class="btn btn-primary btn-sm block">Yes</button>
          </div>
        </div>
      </div>
    </div>
  
  </div>
  <div class="col-md-6">
  	<h3>Result Array</h3>

      <h4 class="text-primary">[ raw ] <span>Kata dengan Koma</span></h4>
      <textarea name="rawF" id="rawF" class="form-control vertical" rows="15"></textarea>
      <div class="text-right">
        <button class="btn btn-info btn-sm" title="copy to clipboard" onclick="copyToClipboard('#rawF')">copy</button>
      </div>
      <h4 class="text-primary">[ javascript ] <span>var array_name = </span><br> [ python ] <span>list_name = </span></h4>
      <textarea name="jsF" id="jsF" class="form-control vertical" rows="15" cols="auto"></textarea>
      <div class="text-right">
        <button class="btn btn-info btn-sm" title="copy to clipboard" onclick="copyToClipboard('#jsF')">copy</button>
      </div>
      <h4 class="text-primary">[ php ] <span>$array_name =  </span><br> [ perl ] <span>@array_name = </span></h4>
      <textarea name="phpF" id="phpF" class="form-control vertical" rows="15"></textarea>
      <div class="text-right">
        <button class="btn btn-info btn-sm" title="copy to clipboard" onclick="copyToClipboard('#phpF')">copy</button>
      </div>

  
  </div>
</div>
  
</div>
<script type="text/javascript">
		$(function() {
		
			$("#codearea").linedtextarea();
			$("#codearea").textareaCount({
 
			  // Default: Infinity
			  maxCharacterSize: 999999
			  
			});
			
			$(window).on('resize', function() {
				width = $('.workspace').outerWidth();
				$('#codearea').css('width', (width - $('.codelines').outerWidth() - 10 ));
			});

		});

		function copyToClipboard(element) {
			var $temp = $("<input>");
			$("body").append($temp);
			$temp.val($(element).text()).select();
			document.execCommand("copy");
			$temp.remove();
			
			Swal.fire({
					  	title: 'Berhasil',
					  	text: 'Text Berhasil Disalin',
					})
		}
		
		$('.btn-clear-all').click(function() {
			$('#codearea').val("");
			// output
			$('#rawF').html("");
			$('#jsF').html("");
			$('#phpF').html("");
		//	$('#pythonF').html("");
		//	$('#perlF').html("");
		});

</script>