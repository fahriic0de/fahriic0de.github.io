<?php include('session.php'); ?>
<?php
	include('config.php');
	session_start(); ?>
<?php include'helixdata/head.php' ?>
<?php include'helixdata/sidebar.php' ?>
<!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between flex-wrap">
                <div class="d-flex align-items-center dashboard-header flex-wrap mb-3 mb-sm-0">
                  <h5 class="mr-4 mb-0 font-weight-bold"><?php if ( !$judul ){ echo 'Tools'; } else { echo str_replace("_", " ", "$judul") . '';} ?></h5>
                </div>
                <div class="d-flex">
                  <button class="btn btn-light border d-none d-sm-block">Download Source</button>
                </div>
              </div>
            </div>
          </div>
          <?php
$judul=@IP_Checker;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          	<table class="table table-bordered table-striped">
		<thead>
		<p>Domain:&nbsp;&nbsp;&nbsp;</p>
        <form action="">
		<input type="text" name="q" class="form-control text-danger" autocomplete="off" placeholder="4dh4x0r.id" value="<?php htmlspecialchars(@$_REQUEST['q'])?>" /><br> <input type="submit" class="btn btn-outline-primary" value="Go" /></thead>
        </form>
</div>
<?php
if(trim(@$_REQUEST['q']))
{
	$q = $_REQUEST['q'];
	if(preg_match("#\\d+\\.\\d+.\\.\\d+.\\.\\d+.#",$q))
	{
		$res = gethostbyaddr($q);
	}
	else
	{
		$res = gethostbyname($q);
	}
	echo "<br/>Host Address:<br/><br/>";
	echo "<b>$res</b><br/>";
}
?>
	</table> <?php include'helixdata/footer.php' ?>