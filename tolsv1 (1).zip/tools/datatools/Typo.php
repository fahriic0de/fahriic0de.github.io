<?php
$judul=@Cek_Typo;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
<div class="container">
<div class="row">
  <div class="col-md-6">
  	<h3>Text</h3>
  	<textarea id="input" name="input" class="form-control vertical" rows="15"></textarea><br>
  	<button id="btnproses" type="button" class="btn btn-primary btn-block">Cek</button>
  </div>
  <div class="col-md-6">
  	<h3>Hasil</h3>
  	<p class="text-danger">Note : Kata yang Typo adalah yang berwarna Merah</p>
  	<div id="output">
  <textarea id="output" name="output" class="form-control vertical" rows="5"> </textarea>
  </div>
  </div>
</div>
  
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
  $("#output").keydown(false);
  $('[data-toggle="tooltip"]').tooltip();   
});

  $('#btnproses').on('click', function () {
            
          url = "API/Typo.php";
          var data=new FormData();
          var input     = document.getElementById("input").value;
          data.append('input',input);

      
           
          
          $.ajax({
            url : url,
            type : "POST",
            data : data,
            processData: false, 
            contentType: false,
            success : function(data){
              
              $("#output").html(data);
            },
            error : function(){
                $("#output").html('Something Error !');
            }        
          });
          return false;
      });
</script>