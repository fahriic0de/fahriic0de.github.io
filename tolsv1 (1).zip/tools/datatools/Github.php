<?php
$judul=@Github_Archive_Downloader;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <?php
$errors = "";
error_reporting(0);
if(empty($_POST) == false) {
  $url = $_POST["url"];
  $choice = $_POST["choice"];
  if(empty($url) == true) {
    $errors = "Please Enter The Url";
  } else if(preg_match("/https:\/\/github.com\/(.*?)/",$url) == false){
    $errors = "Bakaaaa, Masukin link yang benar dong °^° ";
  } else {
    if(fopen($url, "r")){
      $download_url = $url . "/archive/master.zip";
      if ($choice == "l") {
       $errors = "<a class='btn btn-outline-danger' href='$download_url'>Download ".end(explode("/", $url)) . "</a>";
      } else {
        header("location:$download_url");
      }
    } else {
     $errors = "File not Exists";
    }  if(fopen($url, "r")){
      $download_url = $url . "/archive/master.zip";
  }if ($choice == "d") {
       $errors = "header('location:$url/archive/master.zip ".end(explode("/", $url)) . "')";
      }
}
}
?>

                <form action="" method="post">
                  <label for="url">Link :</label>
                  <input type="url" id="url" name="url" class="form-control text-danger" autocomplete="off">
                  <label for="url">Choice:</label>
                  <input type="radio" name="choice" value="l" checked>Get Download Link
                  <input type="radio" name="choice" value="d">Direct Download
                  <div align="center">
                    <input type="submit" name="submit" class="btn btn-outline-danger" value="submit">
                    </div> 
                 
              <?php 
              if(empty($errors) == false){
                ?>
                <div class="error"><?php echo "$errors";?></div>
              <?php
              }
              ?>
           