<?php
$judul=@Google_Drive_Direct_Download;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <div class="content">
          <input type="text" class="form-control" id="sharelink" placeholder="https://drive.google.com/file/d/XX-X__XXXXX-XXXXXXXXXXXXXXXX/view?usp=sharing" autofocus="true">
        </div>
        <div class="form-group">
          <label for="downloadlink">Download link</label>
          <div class="input-group">
            <input type="text" class="form-control" id="downloadlink" readonly>
        <button id="copylinkbtn" class="btn btn-primary" type="button" data-clipboard-target="#downloadlink" disabled>Copy link</button>
          </div>
        </div>
      </form>

  <button class="btn btn-default" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
  Show instructions
</button>
  <div class="collapse" id="collapseExample">
   <br />
    <div class="well text-center">
      <img src="https://drive.google.com/uc?export=download&id=0B-B__6JMBt-jb1MxWHY5UE5QUXM" alt="" />
    </div>
  </div>      
      
    </div>
  </div>
  <?php include "assets/footer.php";?>
</div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.10/clipboard.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mouse0270-bootstrap-notify/3.1.5/bootstrap-notify.min.js'></script>

    <script src="helixdata/js/indexs.js"></script>