<?php
$judul=@Charcode;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <script>
		function salin() {
			document.getElementById("output").select();
			document.execCommand("copy");
			            		Swal.fire({
					  	title: 'Berhasil',
					  	text: 'Text Berhasil Disalin',
					})
		}
	function runCharCodeAt() {
			input = document.charCodeAt.input.value;
			output = "";
			for(i=0; i < input.length; ++i) {
				if (output != "") output += "";
				output += input.charCodeAt(i);
			}
			document.charCodeAt.output.value = output;
		}
	</script>
	
				<div class="tile-body">
					<form name="charCodeAt" method="post">
		<textarea name="input" class="form-control" placeholder="Text" rows="8"></textarea>
				</div>
			<br>
			<div class="row">
				<div class="col">
					<button type="button" onclick="runCharCodeAt()" class="btn btn-primary btn-block">Create</button>
		</div>
	<div class="col">
			<button type="button" onclick="salin()" class="btn btn-success btn-block">Salin</button>
				</div>
			</div>
		<br>
			<textarea id="output" class="form-control bg-transparent" rows="8" placeholder="Charcode readonly="readonly"></textarea>