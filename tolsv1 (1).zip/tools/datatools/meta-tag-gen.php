<?php
$judul=@Meta_Tag_Generator ?>
<div class="container">
<div class="row">
<div class="col">
<div class="card">
<div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
<div class="card-body">
<div class="table-responsive">

<?

		if(isset($_GET['action'])){
			$action = $_GET['action'];
		}else
			$action = NULL;
		if(isset($_POST['getmetafrompage'])){
			$getmetafrompage = $_POST['getmetafrompage'];
		}else
			$getmetafrompage = NULL;

		if ($action == "1")
		{
			print "<P>Insert the following HTML code between the &lt;HEAD&gt; tags of your site:";
			print "<FORM><TEXTAREA CLASS=form-control id=HelixUwU ROWS=8 COLS=65 style='width: 600px;'>&LT;META NAME=\"description\" CONTENT=\"$_POST[desc]\"&GT;\n";
			print "&LT;META NAME=\"keywords\" CONTENT=\"$_POST[keyw]\"&GT;\n";
			if(isset($_POST['robots'])){
				if ($_POST['robots'] == "yes")
				{
					print "&LT;META NAME=\"robot\" CONTENT=\"$_POST[robotsoption]\"&GT;\n";
				}
			}

			if(isset($_POST['refresh'])){
				if ($_POST['refresh'] == "yes")
				{
					print "&LT;META NAME=\"refresh\" CONTENT=\"$_POST[refreshafter]\"&GT;\n";
				}
			}

			if(isset($_POST['copyright'])){
				if ($_POST['copyright'] == "yes")
				{
					print "&LT;META NAME=\"copyright\" CONTENT=\"$_POST[copyrighttext]\"&GT;\n";
				}
			}

			if(isset($_POST['author'])){
				if ($_POST['author'] == "yes")
				{
					print "&LT;META NAME=\"author\" CONTENT=\"$_POST[authorname]\"&GT;\n";
				}
			}

			if(isset($_POST['generator'])){
				if ($_POST['generator'] == "yes")
				{
					print "&LT;META NAME=\"generator\" CONTENT=\"$_POST[generatorname]\"&GT;\n";
				}
			}

			if(isset($_POST['language'])){
				if ($_POST['language'] == "yes")
				{
					print "&LT;META NAME=\"language\" CONTENT=\"$_POST[languagetype]\"&GT;\n";
				}
			}

			if(isset($_POST['revisit'])){
				if ($_POST['revisit'] == "yes")
				{
					print "&LT;META NAME=\"revisit-after\" CONTENT=\"$_POST[revisitdays]\"&GT;\n";
				}
			}
			print "</TEXTAREA></FORM><br>";
            print "<button class='btn btn-outline-warning' onclick=myFunction()>Copy Text</button></center>";

		}
		else
		{
			if(isset($MetaTags["description"]))
				$description = $MetaTags["description"];
			else
				$description = NULL;

			if(isset($MetaTags["keywords"]))
				$keywords = $MetaTags["keywords"];
			else
				$keywords = NULL;

			if(isset($MetaTags["robots"]))
				$robot = $MetaTags["robots"];
			else if(isset($MetaTags["robot"]))
				$robot = $MetaTags["robot"];
			else
				$robot = NULL;

			if(isset($MetaTags["author"]))
				$author = $MetaTags["author"];
			else if(isset($MetaTags["owner"]))
				$author = $MetaTags["owner"];
			else
				$author = NULL;

			if(isset($MetaTags["refresh"]))
				$refresh = $MetaTags["refresh"];
			else
				$refresh = NULL;

			if(isset($MetaTags["copyright"]))
				$copyright = $MetaTags["copyright"];
			if(isset($MetaTags["dc_rights"]))
				$copyright = $MetaTags["dc_rights"];	
			else
				$copyright = NULL;

			if(isset($MetaTags["revisit-after"]))
				$revisit = $MetaTags["revisit-after"];
			else
				$revisit = NULL;

			if(isset($MetaTags["generator"]))
				$generator = $MetaTags["generator"];
			else
				$generator = NULL;

			if(isset($MetaTags["language"]))
				$language = $MetaTags["language"];
			else
				$language = NULL;

			$year = date('y');

			print "<FORM ACTION=\"$_SERVER[PHP_SELF]?tools=meta-tag-gen&action=1\" METHOD=post>";
			print "<b>Deskripsi Website : </B><BR><input type=\"text\" class=\"form-control text-warning\" size=\"40\" name=\"desc\" VALUE=\"$description\"><br>";
			print "<br><b>Keyword : </B>(Pisahkan Kata Dengan Koma) : </b><BR><input type=\"text\" class=\"form-control text-warning\" size=\"40\" name=\"keyw\" VALUE=\"$keywords\"><br><br />";
			print "<B><I>Opsi Tambahan :</I></B> <BR>(☑Centang Bilas Anda Ingin<P>";
			print "<INPUT TYPE=checkbox NAME=robots class=\"form-check-primary\" VALUE=yes ";

			if (isset($robot))
				print "CHECKED";
			print "> <br> Izinkan Search Engine untuk";
			print "&nbsp;&nbsp;&nbsp;&nbsp;<SELECT class=\"form-control text-warning\" NAME=robotsoption>";

			if (isset($robot))
				print "<OPTION class=\"form-control text-warning\" value='$robot'>$robot</OPTION>";
			print "<OPTION class=\"form-control text-warning\" VALUE=\"index,follow\">Index page, follow all links</OPTION><OPTION VALUE=\"noindex,nofollow\">No Index page, No follow links</OPTION>";
			print "<OPTION class=\"form-control text-warning\" VALUE=\"index,nofollow\">Index page, No follow links</OPTION><OPTION VALUE=\"noindex,follow\">NO Index page, follow links</OPTION></SELECT><P>";
			print "<br><INPUT TYPE='checkbox' NAME=refresh VALUE=yes ";

			if (isset($refresh))
				print "CHECKED";
			print "> Refresh halaman ini  <INPUT TYPE=text NAME=refreshafter class=\"form-control text-warning\" SIZE=3 VALUE=\"$refresh\"> seconds<P>";
			print "<br><INPUT TYPE=checkbox NAME=copyright VALUE=yes ";

			if (isset($copyright))
				print "CHECKED";
			print "> Copyright line: &nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE=text class=\"form-control text-warning\" NAME=copyrighttext value=\"";

			if (isset($copyright))
				print "$copyright";
			else
				print "Copyright &copy 20$year";
                        print "\" SIZE=35><P>";
			print "<br><INPUT TYPE=checkbox NAME=author VALUE=yes ";

			if (isset($author))
				print "CHECKED";
			print "> Author: &nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE=text class=\"form-control text-warning\" NAME=authorname SIZE=35 VALUE=\"$author\"><P>";
			print "<br><INPUT TYPE=checkbox NAME=generator VALUE=yes ";

			if (isset($generator))
				print "CHECKED";
			print "> Generator: &nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE=text class=\"form-control text-warning\" NAME=generatorname SIZE=35 VALUE=\"$generator\"><P>";
			print "<br><INPUT TYPE=checkbox NAME=language VALUE=yes ";

			if (isset($language))
				print "CHECKED";
			print "> Bahasa (Language): &nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE=text class=\"form-control text-warning\" NAME=languagetype SIZE=35 VALUE=\"$language\"><P>";
			print "<br><INPUT TYPE=checkbox NAME=revisit VALUE=yes ";

			if (isset($revisit))
				print "CHECKED";
			print "> Search engines akan revisit halaman ini setelah (Day) <INPUT TYPE=text class=\"form-control text-warning\" NAME=revisitdays SIZE=3 VALUE=\"$revisit\"> days.<P>";
			print "<br><INPUT TYPE=submit class='btn btn-outline-primary' VALUE=\"Generate\"><P>";
			print "</FORM>";
		}

?>
<script>
function myFunction() {
var copyText = document.getElementById("HelixUwU");
copyText.select();
copyText.setSelectionRange(0, 99999);
document.execCommand("copy");
alert("Success Copy " + copyText.value);
}
</script>
