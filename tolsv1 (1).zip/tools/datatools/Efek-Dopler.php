<?php
$judul=@Efek_Dopler;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <div class="clear"> </div>
    <font size="+2" color="#FFFFFF">Efek Dopler (Sumber Suara Mendekati Penerima)</font>
    <p>Efek dopler menjelaskan kalau ada sumber bunyi yang menjauhi atau mendekati pendengar, maka frekuensi yang didengar oleh si pendengar akan naik turun (perubahan frekuensi). Di sini kita dapat menghitung Frekuensi yang Mendekati Penerima. </p>  

	<form name=first>
	    <br>
		<div id="dispCalcConts"> <div class="group clearfix">
       <select class="form-control text-danger" name=ss onchange="modf()">
			<option value=4>Menghitung Frekuensi Pendengar (f<sub>p</sub>)</option>
			<option value=1>Menghitung Frekuensi Sumber Bunyi (f<sub>s</sub>)</option>
			<option value=2>Menghitung Kecepatan Pendengar (V<sub>p</sub>)</option>
			<option value=3>Menghitung Cepat Rambat Bunyi (v)</option>
			</select>
     </div>
      <div class="group clearfix">
          <br>
       <label>Frekuensi Sumber Bunyi (f<sub>s</sub>)</label>
       <span class="width_100"><div class="input-group"><input id="res1" type="text" size="50" height="10"class="form-control text-warning"><br>Hz</div></span>
     </div>
      <div class="group clearfix">
          <br>
       <label>Kecepatan Sumber Bunyi (V<sub>s</sub>)</label>
       <span class="width_100"><div class="input-group"><input id="res2" type="text" size="50" height="10"class="form-control text-warning"><br>m/s</div></span>
     </div>
 <div class="group clearfix">
     <br>
       <label>Cepat Rambat Bunyi (v)</label>
       <span class="width_100"><div class="input-group"><input id="res3" type="text" size="50" height="10"class="form-control text-warning"><br>m/s</div></span>
     </div>
      <div class="group clearfix">
          <br>
       <label>Frekuensi Pendengar (f<sub>p</sub>) </label>
       <span class="width_100"><div class="input-group"><input id="res4" type="text" size="50" height="10"class="form-control text-warning"><br>Hz</div></span>
     </div>
     <br>
     <center>
     <button class="btn btn-outline-primary" type=button value=Calculate class=calc onclick=calsi()>Hitung</button>
     <button class="btn btn-outline-warning" type=reset value=Reset>Reset</button></center></div>	</form>
     
  <br>
  <br>
<script type="text/javascript">
	var easyinputs = document.getElementsByTagName("INPUT");
	for (var ies = 0; ies < easyinputs.length; ies++)
	{
	    if (easyinputs[ies].type === 'button')
	    { 
		easyinputs[ies].style.visibility='hidden';
		if ((easyinputs[ies].offsetTop-10)<0)
		{
			document.getElementById("overlayLoader").style.top = (document.getElementById('dispCalcConts').offsetTop+(document.getElementById('dispCalcConts').offsetHeight/4))+"px";
		}
		else
		{
			document.getElementById("overlayLoader").style.top = (easyinputs[ies].offsetTop-10)+"px";
		}
	    }
	    else
	    {
		document.getElementById("overlayLoader").style.top = (document.getElementById('dispCalcConts').offsetTop+(document.getElementById('dispCalcConts').offsetHeight/4))+"px";
	    }
	    if (easyinputs[ies].type === 'reset')
	    { 
		easyinputs[ies].style.visibility='hidden';
	    }
	}
</script>


  

<script type="text/javascript">
	var chf_rss=true;
	function getPathFromUrl(url){return url.split("?")[0];}
	var curUrl = window.location.pathname; 
	var basName = curUrl.replace(/^.*[\/\\]/g, '');
	var curencyIndx = false;
</script>

<script type="text/javascript">
function calsi()
{
	var ty = document.first.ss.value;
	var s = document.first.res1.value;
	var r  = document.first.res2.value;
	var v = document.first.res3.value;
	var f = document.first.res4.value;
	if(ty == 1)
		s = null;
	if(ty == 2)
		r = null;
	if(ty == 3)
		v = null;
	if(ty == 4)
		f = null;
	if(s == "" || r == "" || v == "" || f == "")
	{
		alert(" Isi Yang Bener Dong, Ngetik Aja Remed ");
	}
	if(s != null && r != null && v != null){
		f = Math.round(((v/(v-r))*s)*100)/100;
		document.first.res4.value=f;
	}
	else if(v != null && r != null && f != null){

		s = Math.round((f/(1+parseFloat(r/v)))*100)/100;

		document.first.res1.value=s;

	}

	else if(s != null && v != null && f != null){

		r = Math.round((v*((f/s)-1))*100)/100;

		document.first.res2.value=r;

	}

	else if(s != null && r != null && f != null){

		v = Math.round((r/((f/s)-1))*100)/100;

		document.first.res3.value=v;

	}

	return false;

}



function modf()

{

	for(var h=1; h<5; h++)

	{

		var dd = "document.first.res"+h;

		ss = eval(dd);

		ss.disabled=false;

		//ss.style.backgroundColor="#eefaff";

		//ss.style.color= "#000000";

	}

	var vv = document.first.ss.value;

	sse(vv);

}



function sse(vv){

	var dd = "document.first.res"+vv;

	ss = eval(dd);

	ss.disabled=true;

	ss.value="";

	//ss.style.color= "black";

	//ss.style.backgroundColor="#bbc7dd";

}



</script>		<script type="text/javascript">
		function alert(val)
		{
		    $("#dynErrDisp").show();
		    $("#dynErrDisp").html(val);
		}
		$(document).ready(function() {
			closeModal();
		});
		</script>

<script type="text/javascript">
	var mobiScrnWidth = $(window).width();
	function showhidetopcate(obj) {if (mobiScrnWidth < 480){var currightid = obj.id;if(currightid == "topcaterightbox") {$("#popcalcrightbox ul").hide();}else if(currightid == "popcalcrightbox") {$("#topcaterightbox ul").hide();}$("#"+currightid+" ul").show();}}
	$(document).ready(function(){if (mobiScrnWidth < 480){$("#popcalcrightbox ul").hide();$("#topcaterightbox ul").hide();}});
</script>

<script type="text/javascript">
if(tblfilename!="allele-frequency-calculator.php") {
  window._taboola = window._taboola || [];
  _taboola.push({flush: true});
}
</script> 