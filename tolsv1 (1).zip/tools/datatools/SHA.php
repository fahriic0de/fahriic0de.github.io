<?php
$judul=@SHA_Encoder;
include'sec.php';
error_reporting(0);
?>

<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
        <center>
            <textarea class="form-control text-primary" id="encodestring"></textarea>
            <br><br>
            <table class="table">
                <tr>
                    <td>
                        <select class='form-control' id="type">
                            <option value="SHA1" selected="">SHA1</option>
                            <option value="SHA224">SHA224</option>
                            <option value="SHA256">SHA256</option>
                            <option value="SHA384">SHA384</option>
                            <option value="SHA512">SHA512</option>
                            <option value="SHA3">SHA3</option>
                        </select>
                    </td>
                </tr>
            </table>
            <br>
            <input type="submit" class="btn btn-outline-primary" id="encode" value="Encode">&nbsp;&nbsp;
            <button class="btn btn-outline-warning" onclick="myFunction()">Copy Text</button>
            <br><br>
            <textarea class="form-control text-primary" id="encryptedstring"></textarea>
        </center>
<script src="jquery.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.js" type="text/javascript"></script>
<script>
    $("#encode").click(function() {
    var e = $("#type").val();
    if ("SHA1" == e) var S = CryptoJS.SHA1($("#encodestring").val());
    else if ("SHA224" == e) S = CryptoJS.SHA224($("#encodestring").val());
    else if ("SHA256" == e) S = CryptoJS.SHA256($("#encodestring").val());
    else if ("SHA384" == e) S = CryptoJS.SHA384($("#encodestring").val());
    else if ("SHA512" == e) S = CryptoJS.SHA512($("#encodestring").val());
    else if ("SHA3" == e) S = CryptoJS.SHA3($("#encodestring").val());
    $("#encryptedstring").val(S)
});
</script>
<script>

    function myFunction() {
      var copyText = document.getElementById("encryptedstring");
    
      copyText.select();
      copyText.setSelectionRange(0, 99999);
    
      document.execCommand("copy");
    
      alert("Berhasil Copy Text " + copyText.value);
    }

</script>