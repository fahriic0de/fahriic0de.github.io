<?php
$judul=@Shorten_URL_V2;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<center> 
<form action="" method="post">
    <br>
    <label>Link</label>
	<input type="text" name="url" class="form-control">
	<br>
	<input type="submit" name="submit" class="btn btn-outline-warning" value="Shorten">
</form>
<?php

if (isset($_POST['submit'])) {
 
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 
function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
 
    return $random_string;
}

$alias = generate_string($permitted_chars, 15); //ganti angka sesuai jumlah yang kamu mau
$url = urlencode($_POST['url']);
$api_token = '875f64d7ba671329a29cdb7cd6f91fc7c8cf31da'; //DEVELOPER API 
$api_url = "https://link.helixs.tech/api?api=$api_token&url=$url&alias=$alias";
$result = file_get_contents($api_url);
$result =  json_decode(file_get_contents($api_url),TRUE);
if($result["status"] === 'error') {
echo '<br><div class="alert alert-danger"> Error '. $result["message"] .'</div>';
} else {
echo "<br><div class='alert alert-success'> <a href=". $result['shortenedUrl'] ." >". $result['shortenedUrl'] ."</a></div>";
}

}
?>
</center>