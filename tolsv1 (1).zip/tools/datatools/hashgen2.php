<?php
$judul=@Hash_Generator;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <script>
	function md2() {
			document.getElementById("md2").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function md4() {
			document.getElementById("md4").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function md5() {
			document.getElementById("md5").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function sha1() {
			document.getElementById("sha1").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function sha224() {
			document.getElementById("sha224").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function sha512() {
			document.getElementById("sha512").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function ripemd256() {
			document.getElementById("ripemd256").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function Bc() {
			document.getElementById("Bc").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
	function Bb() {
			document.getElementById("Bb").select();
			document.execCommand("copy");
			alert("UwU Copy Success");
		}
</script>
	
<div class="tile">
	<form method="post">
		<input type="text" name="pass" class="form-control mb-3" placeholder="Text">
		<center>
		<button type="submit" name="hash" class="btn btn-outline-primary">Hash Text/Password</button>
		</center>
	</form>
</div>

<?php
if(isset($_POST["hash"])){
	$pass = htmlspecialchars(addslashes($_POST["pass"]));
if(!empty($pass)){
echo '<br><center>
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Md2</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("md2",$pass).'" onclick="md2()" id="md2">
		</div>
	</div>
	<br>
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Md4</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("md4",$pass).'" onclick="md4()" id="md4">
		</div>
	</div>

<br>
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Md5</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.md5($pass).'" onclick="md5()" id="md5">
		</div>
	</div>
<br>	
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Sha1</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.sha1($pass).'" onclick="sha1()" id="sha1">
		</div>
	</div>

<br>
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Sha224</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("sha224",$pass).'" onclick="sha224()" id="sha224">
		</div>
	</div>
<br>	
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Sha512</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("sha512",$pass).'" onclick="sha512()" id="sha512">
		</div>
	</div>

<br>
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Ripemd256</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.hash("ripemd256",$pass).'" onclick="ripemd256()" id="ripemd256">
		</div>
	</div>
<br>	
	<div class="col-md-6">
		<div class="tile">
			<font class="text-warning" size="3">Bcrypt Default</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.password_hash($pass,PASSWORD_DEFAULT).'" onclick="Bc()" id="Bc">
		</div>
	</div>
<br>
<div class="tile">
	<font class="text-warning" size="3">Bcrypt Blowfish</font>
			<input type="text" readonly="readonly" class="form-control bg-transparent" value="'.password_hash($pass,PASSWORD_BCRYPT).'" onclick="Bb()" id="Bb"></center>';
	}
}
?>