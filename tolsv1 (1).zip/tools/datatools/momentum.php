<?php
$judul=@Momentum;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">

<font color="#FFFFFF" size="+2">Momentum (P=MV)</font>
<p style="font-size:0.95em; color:#FFF">momentum dapat didefinisikan sebagai perkalian antara massa benda dengan kecepatan benda </p>  
     <!-- ec_calculator begins -->

<br>
	<form name="first">
<center>
		<div id="dispCalcConts" style="opacity: 1;"> <div class="group clearfix">
		    <br>
       <label>Massa (m)</label>
       <div class="input-group"><input id="inp1" type="text" size="50" height="10"class="form-control text-warning"><br>kg</div>
		</div>
      <div class="group clearfix">
          <br>
       <label>Kecepatan (v)</label>
       <div class="input-group"><input id="inp2" type="text" size="50" height="10" class="form-control text-warning"><br>m/s</div>
      </div>
<input class="btn btn-outline-primary" type="button" onclick="add()" value="Hitung"> 
<input class="btn btn-outline-warning" type="reset" value="Reset" >

     <div class="result">
      <div class="group clearfix">
          <br>
       <label>Momentum (P=MV)</label>
       <div class="input-group"><input id="resl" type="text" size="50" height="10"class="form-control text-info" readonly></div>
     </div>
     </div></div>	</center></form>


     <br>
<script type="text/javascript">
	var easyinputs = document.getElementsByTagName("INPUT");
	for (var ies = 0; ies < easyinputs.length; ies++)
	{
	    if (easyinputs[ies].type === 'button')
	    { 
		easyinputs[ies].style.visibility='hidden';
		if ((easyinputs[ies].offsetTop-10)<0)
		{
			document.getElementById("overlayLoader").style.top = (document.getElementById('dispCalcConts').offsetTop+(document.getElementById('dispCalcConts').offsetHeight/4))+"px";
		}
		else
		{
			document.getElementById("overlayLoader").style.top = (easyinputs[ies].offsetTop-10)+"px";
		}
	    }
	    else
	    {
		document.getElementById("overlayLoader").style.top = (document.getElementById('dispCalcConts').offsetTop+(document.getElementById('dispCalcConts').offsetHeight/4))+"px";
	    }
	    if (easyinputs[ies].type === 'reset')
	    { 
		easyinputs[ies].style.visibility='hidden';
	    }
	}
</script>
<br>
<div class="formula">
 <h4>Rumus:</h4>
 <font>P=MV </font>
<b>Dimana,</b><br>
P = Momentum<br>    
M = Massa    <br>
V = Keceepatan <br></div>
</center>

<script type="text/javascript">
	var chf_rss=true;
	function getPathFromUrl(url){return url.split("?")[0];}
	var curUrl = window.location.pathname; 
	var basName = curUrl.replace(/^.*[\/\\]/g, '');
</script>

<script type="text/javascript">


function add()
{
      var inp1 = $("#inp1").val();
      var inp2 = $("#inp2").val();  
      if(inp1=="" || inp2=="")
      {
          alert("Please enter all required feilds");
          return false;
      }
      else
      {
          var resl = parseFloat(inp1) * parseFloat(inp2);
          $("#resl").val(resl);
      }
}
</script>		<script type="text/javascript">
		function alert(val)
		{
		    $("#dynErrDisp").show();
		    $("#dynErrDisp").html(val);
		}
		$(document).ready(function() {
			closeModal();
		});
		</script>
    <script>
	$(document).ready(function() {
	    chf_utils();
	});
    </script>
    <script type="text/javascript">
    var chf_sess = "";
    var chf_sess_mail = "";
    var chf_sess_mobile = "";
</script>