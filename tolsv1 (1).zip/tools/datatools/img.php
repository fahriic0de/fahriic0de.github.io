<?php
$judul=@Image_Encoder;
include'sec.php';
error_reporting(0);
?>
<div class="alert alert-icon-info" role="alert">
	<i data-feather="alert-circle"></i>
	Upload File Images dan Tunggu Beberapa Detik Hingga Selesai Encoding
</div>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
      <script type=text/javascript src=https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js></script>

  <tr>
    <td>

        <center>
            <div class="form-group">
                      <label>File upload</label>
                      <input type=file class=file-upload-default name=userfile id=userfile>
                      <div class="input-group col-xs-12">
                        <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                        <span class="input-group-append">
                          <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                        </span>
                      </div>
                    </div>
            <br><br>
            <div id=preview>
        </center>
        <br><br>
    </td>
  </tr>

<script type=text/javascript>function readFile(evt) { var f = evt.target.files[0]; if (f) { if (/(jpe?g|png|gif|bmp)$/i.test(f.type)) { if (f.size < 800000) { var r = new FileReader(); r.onload = function(e) { $('#filechoose').val(f.name); var base64Img = e.target.result; var html = '<img src="' + base64Img + '" height="280" width="260"/><br><br>'; html += '<font color="silver" size="5">Base64 String</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="1">' + base64Img + '</textarea><br><br><button class="btn btn-outline-warning" onclick="myFunction()">Copy Text</button><br><br>'; html += '<font color="silver" size="5">CSS Background IMG</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="2">' + '&lt;style type="text/css"&gt;\n' + 'div.image {\n' + 'width: 100px;\n' + 'height: 100px;\n' + 'background-image: url("' + base64Img + '");\n' + '}\n' + '&lt;/style&gt;\n' + '</textarea><br><br><button class="btn btn-outline-warning" onclick="myFunctionn()">Copy Text</button><br><br>'; html += '<font color="silver" size="5">XHTML IMG</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="3"> &lt;img src="' + base64Img + '"/&gt;</textarea><br><br><button class="btn btn-outline-warning" onclick="myFunctionnn()">Copy Text</button><br><br>'; html += '<font color="silver" size="5">XML IMG</font><br><br><textarea class="form-control text-danger" cols="auto" rows="10"  id="4">' + '&lt;image&gt;\n' + '&lt;title&gt;An Image&lt;/title&gt;\n' + '&lt;link&gt;http://www.your.domain&lt;/link&gt;\n' + '&lt;url&gt;' + base64Img + '&lt;/url&gt;\n' + '&lt;/image&gt; </textarea><br><br><button class="btn btn-outline-warning" onclick="myFunctionnnn()">Copy Text</button><br><br>'; $('#preview').html(html); }; r.readAsDataURL(f); } else { alert("File size is big."); } } else { alert("DISURUH UPLOAD FILE IMAGES BUKAN PHP"); } } else { alert("Gagal load file."); } } document.getElementById('userfile').addEventListener('change', readFile, false);</script>
<script> function myFunction() { var copyText = document.getElementById("1"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionn() { var copyText = document.getElementById("2"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnn() { var copyText = document.getElementById("3"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); } function myFunctionnnn() { var copyText = document.getElementById("4"); copyText.select(); copyText.setSelectionRange(0, 99999); document.execCommand("copy"); alert("Copy The Text : " + copyText.value); }</script>