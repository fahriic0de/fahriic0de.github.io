<?php
$judul=@Cek_Jadwal_Sholat;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><?php echo str_replace("_", " ", "$judul"); ?><button type="button" class="btn btn-primary float-right" id="btn_refresh_sholat"><i class="fas fa-sync"></i> Refresh</button>
    </div>
    <div class="card-body">
      <div class="table-responsive">

        <link rel="stylesheet" href="assets/sweetalert2/sweetalert2.min.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/datatables/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="assets/datatables/css/select.bootstrap4.min.css">
        <link rel="stylesheet" href="assets/datatables/css/buttons.bootstrap4.min.css">
        <link rel="stylesheet" href="assets/select2/css/select2.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css">
        <script src="https://kit.fontawesome.com/7a4dfbbce0.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="assets/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
        <div class="container">
            <div class="content" id="content">
                        <div class="row">
                        	<div class="col-md-6 form-group row">
                        		<label class="col-4 col-form-label text-info">Kota/Wilayah</label>
								<div class="col-8">
									<select name='opt_kota' class='form-control text-warning' id="opt_kota">
	                                    <option class="text-warning" value="">-- Pilih --</option>
	                                    <option class="text-warning" value="">Kalimantan Tengah</option>
	                                    <option class="text-warning" value="">Jakarta</option>
	                                    <option class="text-warning" value="">Riau</option>
	                                    <option class="text-warning" value="">Yogyakarta</option>
	                                </select>
								</div>
                        	</div>

                        	<div class="col-md-6 form-group row">
                        		<label class="col-4 col-form-label text-info">Tanggal</label>
								<div class="col-8">
									<input placeholder="yyyy/dd/mm" type='text' style='width:100%;' name='tanggal' value='' id='tanggal' class='datepick inp_filter filter_tgl form-control text-info' data-date-format='yyyy-mm-dd' readonly>
								</div>
                        	</div>

						</div>
                        
                        <div class="row">
                        	<div class="col-md-12 form-group row">
                        		<div class="col-md-12">
                        			<button type="button" class="btn btn-info float-right mr-4" id="btn_sholat"><i class="fas fa-search"></i> Cari</button>
                        		</div>
                        	</div>
                        </div>

                    </div>
                </div>

				<div id="table-sholat">
					
				</div>

        <script type="text/javascript" src="assets/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="assets/select2/js/select2.min.js"></script>
        <script type="text/javascript" src="assets/sweetalert2/sweetalert2.min.js"></script>
        
        <!-- Data tables -->
        <script type="text/javascript" src="assets/datatables/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="assets/datatables/js/dataTables.bootstrap4.min.js"></script>
        <!-- Datepicker -->
        <script type="text/javascript" src="assets/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>


        <!-- JAVASCRIPT -->
        <script type="text/javascript">

            $(function() {
                opt_kota()
                $("#tanggal").datepicker({
	                startView: 0,
	                minViewMode: 0,
	                autoclose: true,
	            });
            });

            function opt_kota () {
                $.ajax({
                    url: "https://api.banghasan.com/sholat/format/json/kota",
                    type: "GET",
                    dataType: "JSON",
                    crossDomain: true,
                    success: function (r) {

                        var html = ''

                        if(r.status){
                            var result = r.kota
	                                    
                            result.forEach( function(value, index) {
                            	html += `<option class="text-warning" value="`+ value.id +`">`+ value.nama +`</option>`
                            });


                            $('#opt_kota').append(html);
                        }else{
                            alert(r.pesan[0]);
                        }

                    }
                });
            }

            function onClear () {
            	$('#opt_kota').val('')
            	$('#tanggal').val('')
				$('#table-sholat').empty();
            }

            $('#btn_refresh_sholat').on('click', function (){
                onClear();
            })

            $('#btn_sholat').on('click', function () {
            	var kota 	= $('#opt_kota').val()
            	var tanggal = $('#tanggal').val()
            	if (kota != '' && tanggal != '') {
            		$.ajax({
	                    url: "https://api.banghasan.com/sholat/format/json/jadwal/kota/"+ kota +"/tanggal/" + tanggal,
	                    type: "GET",
	                    dataType: "JSON",
	                    crossDomain: true,
	                    success: function (r) {
	                        var html = ''

	                        if(r.status){
	                            var result = r.jadwal.data
	                            html += `
									<div class="card mt-5 mb-5">
					                    <div class="card-header">
					                        <b>Jadwal Sholat Untuk Wilayah ` + $('#opt_kota option:selected').text() + `</b>
					                    </div>
					                    <div class="card-body table-responsive">
					                        <table class="table table-striped table-hover text-info" id="tb_kota">
					                            <thead>
					                                <tr>
					                                  <th scope="col">Tanggal</th>
					                                  <th scope="col">Imsak</th>
					                                  <th scope="col">Subuh</th>
					                                  <th scope="col">Terbit</th>
					                                  <th scope="col">Dhuha</th>
					                                  <th scope="col">Dzuhur</th>
					                                  <th scope="col">Ashar</th>
					                                  <th scope="col">Maghrib</th>
					                                  <th scope="col">Isya</th>
					                                </tr>
					                            </thead>
					                            <tbody>
					                               	<tr>
						                                <td scope="row">`+ result.tanggal +`</td>
						                                <td scope="row">`+ result.imsak +`</td>
						                                <td scope="row">`+ result.subuh +`</td>
						                                <td scope="row">`+ result.terbit +`</td>
						                                <td scope="row">`+ result.dhuha +`</td>
						                                <td scope="row">`+ result.dzuhur +`</td>
						                                <td scope="row">`+ result.ashar +`</td>
						                                <td scope="row">`+ result.maghrib +`</td>
						                                <td scope="row">`+ result.isya +`</td>
						                            </tr> 
					                            </tbody>
					                        </table>
					                    </div>
					                </div>`


	                            $('#table-sholat').empty();
	                            $('#table-sholat').append(html);
	                        }else{
	                        	Swal.fire({
								  	type: 'error',
								  	title: 'Oops...',
								  	text: r.pesan[0],
								})
	                        }
	                    }
	                });
            	} else {
            		Swal.fire({
					  	type: 'error',
					  	title: 'Oops...',
					  	text: 'Silahkan lengkapi parameter diatas!',
					})
            	}
            })
        </script>