<?php
$judul=@Text_Remover;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <script type="text/JavaScript">
<!--
//Remove Duplicate Lines from Text (JavaScript)

function cleartext(){
document.getElementById('input_output').value = '';
document.getElementById('removed').innerHTML = ''
if(document.getElementById('dis_rem').checked == true) document.getElementById('removed_output').value = '';}
function rduplin(){
var text = document.getElementById('input_output').value;
text = text.replace(/\r/g,'');
var textinarr = new Array();
textinarr = text.split('\n');
var len = textinarr.length;
var textoutarr = new Array();
var textoutarrcnt = 0;
var cachearr = new Array();
var cachecnt = 0;
var hash = {};
var xkey = '';
var hkey = '';
var belong2 = 'pbclevtug grkgzrpunavp.pbz';
var cs = document.getElementById('case_sen').checked;
var rel = document.getElementById('rel').checked;
var dis = document.getElementById('dis_rem').checked;

if(cs == true && rel == true && dis == true){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey;
if(hash[hkey] == null && xkey != '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {if(xkey == '') cachearr[cachecnt] = '(Line ' + (x+1) + ' adalah line kosong)'; else cachearr[cachecnt] = '(Line ' + (x+1) + '  adalah Duplikat Line ' + hash[hkey] + '.) ' + xkey; cachecnt++;}}}

if(cs == true && rel == true && dis == false){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey;
if(hash[hkey] == null && xkey != '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {cachecnt++;}}}

if(cs == true && rel == false && dis == true){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey;
if(hash[hkey] == null || xkey == '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {cachearr[cachecnt] = '(Line ' + (x+1) + ' adalah Duplikat Line ' + hash[hkey] + ') ' + xkey; cachecnt++;}}}

if(cs == true && rel == false && dis == false){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey;
if(hash[hkey] == null || xkey == '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {cachecnt++;}}}

if(cs == false && rel == true && dis == true){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey.toUpperCase();
if(hash[hkey] == null && xkey != '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {if(xkey == '') cachearr[cachecnt] = '(Line ' + (x+1) + ' adalah line kosong)'; else cachearr[cachecnt] = '(Line ' + (x+1) + '  adalah Duplikat Line ' + hash[hkey] + '.) ' + xkey; cachecnt++;}}}

if(cs == false && rel == true && dis == false){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey.toUpperCase();
if(hash[hkey] == null && xkey != '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {cachecnt++;}}}

if(cs == false && rel == false && dis == true){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey.toUpperCase();
if(hash[hkey] == null || xkey == '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {cachearr[cachecnt] = '(Line ' + (x+1) + '  adalah Duplikat Line ' + hash[hkey] + ') ' + xkey; cachecnt++;}}}

if(cs == false && rel == false && dis == false){
for(var x=0;x<len;x++){
xkey = textinarr[x];
hkey = ' ' + xkey.toUpperCase();
if(hash[hkey] == null || xkey == '') {hash[hkey] = x+1; textoutarr[textoutarrcnt] = xkey; textoutarrcnt++;} else {cachecnt++;}}}
document.getElementById('input_output').value = textoutarr.join('\n');
if(dis == true) document.getElementById('removed_output').value = cachearr.join('\n');
var lines = 'lines';
if(cachecnt == 1) lines = 'line';
document.getElementById('removed').innerHTML = cachecnt + ' duplicate ' + lines + ' removed';}
function SelectAll(id) {
document.getElementById(id).focus();
document.getElementById(id).select();}
//-->
</script>
<script>
		function copy() {
			document.getElementById("input_output").select();
			document.execCommand("copy");
			Swal.fire({
					  	title: 'Berhasil',
					  	text: 'Text Berhasil Disalin',
					})
		}
	
</script>

<center>
<div id="menubuttonbar"><span id="menubutton"></span></div>
<div>
                        
<textarea id="input_output" class="form-control" style="width:99%; height:382px; margin-top:3px;" wrap="off" spellcheck="false">
Oniichan daisuki >//<
</textarea>
</center><br>
    <input type="checkbox" id="case_sen" />Case sensitive
    <br>
<input type="checkbox" id="rel" />Remove empty lines
<br>
<input type="checkbox" id="dis_rem" onClick="if(this.checked==true)document.getElementById('removed_div').style.display='block'; if(this.checked==false)document.getElementById('removed_div').style.display='none';" />Display removed
<br><br><center>
<input type="button" class="btn btn-outline-danger" title="Select All Text" value=" Select " onClick="SelectAll('input_output')" /> <br><br>
<input type="button" class="btn btn-outline-primary" title="Clear All Text" value=" Clear " onClick="cleartext();" /> <br><br>
			<button type="button" class="btn btn-outline-info" onclick="copy()">Copy</button><br>

<span><br><div class="alert alert-danger" id="removed"></div></span></div></center>
<div id="removed_div" style="display:none;">
<textarea id="removed_output" class="form-control no-bg" rows="6" style="width:99%; margin-top:3px;" wrap="off" spellcheck="false">
Hasil Remove
</textarea></div>
<br><center>
<button type="button" class="btn btn-outline-warning" onClick="rduplin()" />Remove Duplicate Lines</button></center>