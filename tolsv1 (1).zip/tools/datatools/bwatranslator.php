<?php
$judul=@Bwa_Translator;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <div class="conversion"><center>
			<form action="" method="POST">
				Text:<br>
				<textarea class="form-control text-danger" rows="10" cols="90" name="text"></textarea><br><br>
				<input type="submit" class="btn btn-outline-primary" name="submit" value="Translate" />
			</form>
			<?php
				if (isset($_POST['submit'])) {
					$string = $_POST['text'];
					$result_1 = str_replace('a', 'a', $string);
					$result_2 = str_replace('A', 'A', $result_1);
					$result_3 = str_replace('b', 'b', $result_2);
					$result_4 = str_replace('B', 'B', $result_3);
					$result_5 = str_replace('c', 'w', $result_4);
					$result_6 = str_replace('C', 'W', $result_5);
					$result_7 = str_replace('d', 'b', $result_6);
					$result_8 = str_replace('D', 'B', $result_7);
					$result_9 = str_replace('e', 'a', $result_8);
					$result_10 = str_replace('E', 'A', $result_9);
					$result_11 = str_replace('f', 'w', $result_10);
					$result_12 = str_replace('F', 'W', $result_11);
					$result_13 = str_replace('g', 'b', $result_12);
					$result_14 = str_replace('G', 'B', $result_13);
					$result_15 = str_replace('h', 'w', $result_14);
					$result_16 = str_replace('H', 'W', $result_15);
					$result_17 = str_replace('i', 'a', $result_16);
					$result_18 = str_replace('j', 'b', $result_17);
					$result_19 = str_replace('J', 'B', $result_18);
					$result_20 = str_replace('k', 'w', $result_19);
					$result_21 = str_replace('K', 'W', $result_20);
					$result_22 = str_replace('l', 'b', $result_21);
					$result_23 = str_replace('L', 'B', $result_22);
					$result_24 = str_replace('m', 'w', $result_23);
					$result_25 = str_replace('M', 'W', $result_24);
					$result_26 = str_replace('n', 'b', $result_25);
					$result_27 = str_replace('N', 'B', $result_26);
					$result_28 = str_replace('o', 'a', $result_27);
					$result_29 = str_replace('O', 'A', $result_28);
					$result_30 = str_replace('p', 'b', $result_29);
					$result_31 = str_replace('P', 'B', $result_30);
					$result_32 = str_replace('q', 'w', $result_31);
					$result_33 = str_replace('Q', 'W', $result_32);
					$result_34 = str_replace('r', 'b', $result_33);
					$result_35 = str_replace('R', 'B', $result_34);
					$result_36 = str_replace('s', 'w', $result_35);
					$result_37 = str_replace('S', 'W', $result_36);
					$result_38 = str_replace('t', 'b', $result_37);
					$result_39 = str_replace('T', 'B', $result_38);
					$result_40 = str_replace('u', 'a', $result_39);
					$result_41 = str_replace('U', 'A', $result_40);
					$result_42 = str_replace('v', 'b', $result_41);
					$result_43 = str_replace('V', 'B', $result_42);
					$result_44 = str_replace('w', 'w', $result_43);
					$result_45 = str_replace('W', 'W', $result_44);
					$result_46 = str_replace('x', 'b', $result_45);
					$result_47 = str_replace('X', 'B', $result_46);
					$result_48 = str_replace('y', 'w', $result_47);
					$result_49 = str_replace('Y', 'W', $result_48);
					$result_50 = str_replace('z', 'b', $result_49);
					$result_51 = str_replace('Z', 'B', $result_50);
					$result_52 = str_replace('I', 'A', $result_51);
					echo "<br><textarea class='form-control text-danger' rows=\"10\" cols=\"90\">".$result_52."</textarea>";
				}
			?>
			</center>
		</div>