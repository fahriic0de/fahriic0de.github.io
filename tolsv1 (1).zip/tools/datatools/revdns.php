<?php
$judul=@Reverse_DNS;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <div class="conversion"><center>
      <form action="" method="POST">
        DNS:<br>
        <input type="text" class="form-control text-primary" name="sitem">
        <br><br>
        <input type="submit" class="btn btn-outline-primary" name="reverse" value="Reverse" />
      </form></div></div>
<br>
<?php
//$_POST["sitem"];
//$_POST["reverse"];
//if(empty($_POST["reverse"])) {
//exit;
//}


error_reporting(E_ALL);
$ch = curl_init("https://api.hackertarget.com/reversedns/?q=".$_POST["sitem"]."&t=1");
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_NOBODY, 0);
$reverse = curl_exec($ch);

echo '<textarea name="result" id="result" class="form-control" rows="7" readonly>'.$reverse.'</textarea><div class="table table-responsive"></table></thead>';
curl_close($ch);
?>