<?php
$judul=@Video_Downloader;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
         <iframe width="100%" height="500" allowtransparency="true" style="border:none" src="https://vid.helixsid.today//system/embed.php?key=ee61d6b2e7f2687ecaff72eac86a945e1c110015&bg_color=222437"></iframe>
                                         