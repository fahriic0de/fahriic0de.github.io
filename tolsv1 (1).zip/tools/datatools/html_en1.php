<?php
$judul=@HTML_Encrypter_V1;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
        <center>
          <form name="fA">
            <textarea id="f1" wrap="off"></textarea>
            <br><br>
            <input class='btn btn-outline-primary' type="button" value="Encrypt" onclick="document.fA.c1.value=escapeTxt(document.fA.f1.value)">&nbsp;&nbsp;
            <button class='btn btn-outline-warning' onclick="myFunction()">Copy Text</button>
            <br><br>
            <textarea id="c1"></textarea><br>
          </form>
        </center>

<script>

    function myFunction() {
      var copyText = document.getElementById("c1");
    
      copyText.select();
      copyText.setSelectionRange(0, 99999);
    
      document.execCommand("copy");
    
      alert("Copy The Text : " + copyText.value);
    }

</script>
<script>function escapeTxt(os){var ns='';var t;var chr='';var cc='';var tn='';for(i=0;i<256;i++){tn=i.toString(16);if(tn.length<2)tn="0"+tn;cc+=tn;chr+=unescape('%'+tn)}cc=cc.toUpperCase();os.replace(String.fromCharCode(13)+'',"%13");for(q=0;q<os.length;q++){t=os.substr(q,1);for(i=0;i<chr.length;i++){if(t==chr.substr(i,1)){t=t.replace(chr.substr(i,1),"%"+cc.substr(i*2,2));i=chr.length}}ns+=t}return ns}function unescapeTxt(s){return unescape(s)}function wF(s){document.write(decodeTxt(s))}</script>
