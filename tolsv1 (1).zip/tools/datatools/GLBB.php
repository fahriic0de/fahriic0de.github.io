<?php
$judul=@GLBB;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          
<font size="+2" color="#FFFFFF">Kecepatan GLBB</font>
<p style="font-size:0.95em; color:#FFF">Gerak suatu benda pada lintasan garis lurus dengan percepatan tetap</p>  
     
	<form name="first">
	 <div id="overlayLoader" style="top: 452.5px; display: none;">
		    <div class="loader"> </div>
	  </div>
		<div id="dispCalcConts" style="opacity: 1;"><div class="group clearfix">
       <label></label>
      <select id="ss" class="form-control text-danger" onchange="modf()">
			<option value="4">Menghitung Kecepatan(v)</option>
			<option value="1">Menghitung Kecepatan Awal(v0)</option>
			<option value="2">Menghitung Percepatan(a)</option>
			<option value="3">Menghitung Waktu(t)</option>
		  </select>
     </div>
     <div class="group clearfix">
         <br>
       <label>Kecepatan Awal<sub>0</sub>)</label>
       <span class="width_100"><div class="input-group"><input id="res1" type="text" size="50" height="10" class="form-control text-warning"><br>m/s</div></span>
     </div>
     <div class="group clearfix">
         <br>
       <label>Percepatan(a)</label>
       <span class="width_100"><div class="input-group"><input id="res2" type="text" size="50" height="10"class="form-control text-warning"><br>m/s^2</div></span>
     </div>
<div class="group clearfix">
    <br>
       <label>Waktu(t)</label>
       <span class="width_100">
       <div class="input-group"><input id="res3" type="text" size="50" height="10"class="form-control text-warning"><br>sec</div></span>
     </div>
     <div class="group clearfix">
         <br>
       <label>Kecepatan(v) </label>
       <span class="width_100"><div class="input-group"><input id="res4" type="text" size="50" height="10"class="form-control text-warning"><br>m/s</div></span>
     </div><br>
     <center><button type="button" value="Calculate" class="btn btn-outline-primary" onclick="calsi()">Hitung</button>
     <button type="reset" value="Reset" class="btn btn-outline-warning">Reset</button></center>
     </div>	</form>
     
     <br>
    
<script type="text/javascript">
	var easyinputs = document.getElementsByTagName("INPUT");
	for (var ies = 0; ies < easyinputs.length; ies++)
	{
	    if (easyinputs[ies].type === 'button')
	    { 
		easyinputs[ies].style.visibility='hidden';
		if ((easyinputs[ies].offsetTop-10)<0)
		{
			document.getElementById("overlayLoader").style.top = (document.getElementById('dispCalcConts').offsetTop+(document.getElementById('dispCalcConts').offsetHeight/4))+"px";
		}
		else
		{
			document.getElementById("overlayLoader").style.top = (easyinputs[ies].offsetTop-10)+"px";
		}
	    }
	    else
	    {
		document.getElementById("overlayLoader").style.top = (document.getElementById('dispCalcConts').offsetTop+(document.getElementById('dispCalcConts').offsetHeight/4))+"px";
	    }
	    if (easyinputs[ies].type === 'reset')
	    { 
		easyinputs[ies].style.visibility='hidden';
	    }
	}
</script>

<div><div class="f_right"></div></div><div class="clearfix"></div><div class="formula">
	<h4>Rumus:</h4>
	<h4>Kecepatan:</h4> <img src="helixdata/image/cons-acc-velocity.gif" alt="velocity">
	<h4>Kecepatan Awal:</h4> <img src="helixdata/image/cons-acc-ini-velocity.gif" alt="acc">
	<h4>Percepatan:</h4> <img src="helixdata/image/cons-acc-acce.gif" alt="acce">
	<h4>Waktu:</h4> <img src="helixdata/image/cons-acc-time.gif" alt="time">
	<b>Dimana,</b>
	v = Kecepatan,
	v<sub>0</sub> = Kecepatan Awal
	a = Percepatan,
	t = Waktu.</div><br><div class="clear"> </div><div class="clearfix"></div>
  <!-- content_left ends -->
  
  <!-- content_right begins --><!-- content_right ends -->
   
<script type="text/javascript">
	var chf_rss=true;
	function getPathFromUrl(url){return url.split("?")[0];}
	var curUrl = window.location.pathname; 
	var basName = curUrl.replace(/^.*[\/\\]/g, '');
</script>

<script type="text/javascript">
function calsi()
{
	var ty = $("#ss").val();
	var iv = $("#res1").val();
	var a = $("#res2").val();
	var t = $("#res3").val();
	var v = $("#res4").val();
		

	if(ty == 1)
		iv = null;
	if(ty == 2)
		a = null;
	if(ty == 3)
		t = null;
	if(ty == 4)
		v = null;
	
	if(iv == "" || a == "" || t == "" || v == "")
	{
		alert(" Please enter all required feilds ");
	}

	if(iv != null && a != null && t != null){
		v = Math.round((parseFloat(iv) + parseFloat(a*t))*100)/100;
		$("#res4").val(v);
	}
	else if(v != null && a != null && t != null){
		iv = Math.round((parseFloat(v) - parseFloat(a*t))*100)/100;
		$("#res1").val(iv);
	}
	else if(iv != null && v != null && t != null){
		
		a = Math.round(((parseFloat(v) - parseFloat(iv))/t)*100)/100;
		$("#res2").val(a);
	}
	else if(iv != null && v != null && a != null){
		
		t = Math.round(((parseFloat(v) - parseFloat(iv))/a)*100)/100;
		$("#res3").val(t);
	}
	return false;
}

function modf()
{
	for(var h=1; h<5; h++)
	{
		var dd = "document.getElementById('res"+h+"')";
		ss = eval(dd);
		ss.disabled=false;
		//ss.style.backgroundColor="#eefaff";
		//ss.style.color= "#000000";
	}
	var vv = $("#ss").val();
	sse(vv);
}

function sse(vv){
	var dd = "document.getElementById('res"+vv+"')";
	ss = eval(dd);
	ss.disabled=true;
	ss.value="";
	//ss.style.color= "black";
	//ss.style.backgroundColor="#bbc7dd";
}

</script>		<script type="text/javascript">
		function alert(val)
		{
		    $("#dynErrDisp").show();
		    $("#dynErrDisp").html(val);
		}
		$(document).ready(function() {
			closeModal();
		});
		</script>
    <script>
	$(document).ready(function() {
	    chf_utils();
	});
    </script>
    <script type="text/javascript">
    var chf_sess = "";
    var chf_sess_mail = "";
    var chf_sess_mobile = "";
</script>