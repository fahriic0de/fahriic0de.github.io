<?php
$judul=@Morse_Code;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">

<form name="encoder" method=post action="#" onsubmit="return false;">
<select class="form-control text-danger" name="encdec">
   <option value="1">Encrypt Text
   <option value="-1">Decrypt Code
</select>
<center>
    <br>
<p>Text: (<a href="#" onclick="Reverse(); return false">Reverse</a> - 
<a href="#" onclick="SwapMorse(); return false">Swap</a>)<br>
<br>
<textarea class="form-control text-warning" name="text" rows="5" cols="80"></textarea></p>
</form>
<br>
<p>Hasil:</p>
<?php
echo "<from><center>
<textarea id='output' class='form-control text-danger' rows='10' cols='90' readonly>".$html."</textarea></center></from>";
?>
<br>
<button class="btn btn-outline-warning" onclick="myFunction()">Copy Text</button></center>
<br>
<br>
<p class="text-warning">Kode Morse
</p>
<table class="text-info" border=1 cellpadding=3 cellspacing=0>
<tr><td>A &nbsp; <b>.-</bb></td><td>B &nbsp; <b>-...</bb></td><td>C &nbsp; <b>-.-.</bb></td><td>D &nbsp; <b>-..</bb></td><td>E &nbsp; <b>.</bb></td><td>F &nbsp; <b>..-.</bb></td><td>G &nbsp; <b>--.</bb></td><td>H &nbsp; <b>....</bb></td><td>I &nbsp; <b>..</bb></td><td>J &nbsp; <b>.---</bb></td></tr>
<tr>
<td>K &nbsp; <b>-.-</bb></td><td>L &nbsp; <b>.-..</bb></td><td>M &nbsp; <b>--</bb></td><td>N &nbsp; <b>-.</bb></td><td>O &nbsp; <b>---</bb></td><td>P &nbsp; <b>.--.</bb></td><td>Q &nbsp; <b>--.-</bb></td><td>R &nbsp; <b>.-.</bb></td><td>S &nbsp; <b>...</bb></td><td>T &nbsp; <b>-</bb></td></tr>
<tr>
<td>U &nbsp; <b>..-</bb></td><td>V &nbsp; <b>...-</bb></td><td>W &nbsp; <b>.--</bb></td><td>X &nbsp; <b>-..-</bb></td><td>Y &nbsp; <b>-.--</bb></td><td>Z &nbsp; <b>--..</bb></td><td>0 &nbsp; <b>-----</bb></td><td>1 &nbsp; <b>.----</bb></td><td>2 &nbsp; <b>..---</bb></td><td>3 &nbsp; <b>...--</bb></td></tr>
<tr>
<td>4 &nbsp; <b>....-</bb></td><td>5 &nbsp; <b>.....</bb></td><td>6 &nbsp; <b>-....</bb></td><td>7 &nbsp; <b>--...</bb></td><td>8 &nbsp; <b>---..</bb></td><td>9 &nbsp; <b>----.</bb></td><td>. &nbsp; <b>.-.-.-</bb></td><td>, &nbsp; <b>--..--</bb></td><td>? &nbsp; <b>..--..</bb></td><td>- &nbsp; <b>-....-</bb></td></tr>
<tr>
<td>= &nbsp; <b>-...-</bb></td><td>: &nbsp; <b>---...</bb></td><td>; &nbsp; <b>-.-.-.</bb></td><td>( &nbsp; <b>-.--.</bb></td><td>) &nbsp; <b>-.--.-</bb></td><td>/ &nbsp; <b>-..-.</bb></td><td>" &nbsp; <b>.-..-.</bb></td><td>$ &nbsp; <b>...-..-</bb></td><td>' &nbsp; <b>.----.</bb></td><td>&para; &nbsp; <b>.-.-..</bb></td></tr>
<tr>
<td>_ &nbsp; <b>..--.-</bb></td><td>@ &nbsp; <b>.--.-.</bb></td><td>! &nbsp; <b>---.</bb></td><td>! &nbsp; <b>-.-.--</bb></td><td>+ &nbsp; <b>.-.-.</bb></td><td>~ &nbsp; <b>.-...</bb></td><td># &nbsp; <b>...-.-</bb></td><td>&amp; &nbsp; <b>. ...</bb></td><td>&frasl; &nbsp; <b>-..-.</bb></td><td>&nbsp;</td></tr>
</table>
<ul class="text-info">
    <br>
    <p class="text-info">Info
</p>
<li>[Error] &nbsp ......
<li>[Tunggu] &nbsp .-...
<li>[Mengerti] &nbsp ...-.
<li>[Akhir Text] &nbsp .-.-.
<li>[Akhir Pekerjaan] &nbsp ...-.-
<li>[Mulai] &nbsp -.-.-
<li>[Bersiap] &nbsp -.-
</ul>
<script>

    function myFunction() {
      var copyText = document.getElementById("output");
    
      copyText.select();
      copyText.setSelectionRange(0, 99999);
    
      document.execCommand("copy");
    
      alert("Copy Kode Morse : " + copyText.value);
    }

</script>
<script language="JavaScript">
var MorseIndexes = new Array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",'0',"1","2","3","4","5","6","7","8","9",".",",","?","-","=",":",";","(",")","/",'"',"$","'","\n","_","@","[Error]","[Error]","[Error]","[Error]","[Wait]","[Understood]","[End of message]","[End of work]","[Starting signal]","[Invitation to transmit]","!","!","+","~","#","&","\2044");
var MorseCodes = new Array(".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--..","-----",".----","..---","...--","....-",".....","-....","--...","---..","----.",".-.-.-","--..--","..--..","-....-","-...-","---...","-.-.-.","-.--.","-.--.-","-..-.",".-..-.","...-..-",".----.",".-.-..","..--.-",".--.-.","......",".......","........",".........",".-...","...-.",".-.-.","...-.-","-.-.-","-.-","---.","-.-.--",".-.-.",".-...","...-.-",". ...","-..-.");

function SwapMorse()
{
   var s = document.encoder.text.value;
   var o = '';
   
   for (var i = 0; i < s.length; i ++)
   {
      var c = s.charAt(i);
      if (c == '-')
         c = '.';
      else if (c == '.')
         c = '-';
      else if (c == "\r")
         c = '';
      o += c;
   }
   
   document.encoder.text.value = o;
}

function Reverse()
{
   var s = document.encoder.text.value;
   var i = s.length - 1, o = '';
   
   while (i >= 0)
   {
      var c = s.charAt(i);
      if (c != "\r")
         o += c;
      i --;
   }
   
   document.encoder.text.value = o;
}

function getIndex(arr, str)
{
   var i = 0;
   while (arr[i])
   {
      if (arr[i] == str)
      {
         return i;
      }
      i ++;
   }
   return -1;
}

function encode(str)
{
   var addSpace = 0;
   var out = "";
   for (var i = 0; i < str.length; i ++)
   {
      var c = str.charAt(i);
      var j = getIndex(MorseIndexes, c.toUpperCase());
      if (j >= 0)
      {
         if (addSpace)
	 {
	    out += ' ';
	 }
         out += MorseCodes[j];
	 addSpace = 1;
      }
      else
      {
         if (c.charCodeAt(0) == 10 || c.charCodeAt(0) == 13)
	 {
	    out += c;
	 }
	 else if (addSpace)
	 {
	    out += ' / ';
	 }
	 addSpace = 0;
      }
   }
   return out;
}


function decode(str)
{
   var out = "";
   var addSpace = 0;
   tmp = "";
   for (var i = 0; i < str.length; i ++)
   {
      if (str.charCodeAt(i) < 27)
      {
         tmp += ' ' + str.charAt(i) + ' ';
      }
      else if (str.charCodeAt(i) == 8211 || str.charCodeAt(i) == 8212 ||
               str.charAt(i) == '_')
      {

         tmp += '-';
      }
      else if (str.charCodeAt(i) == 8226 || str.charCodeAt(i) == 8901)
      {

         tmp += '.';
      }
      else
      {
         tmp += str.charAt(i);
      }
   }
  
   str = tmp.split(' ');
   for (var i = 0; i < str.length; i ++)
   {
      var idx = getIndex(MorseCodes, str[i]);
      
      if (idx >= 0)
      {
         out += MorseIndexes[idx];
	 addSpace = 1;
      }
      else
      {
         if (str[i].charCodeAt(0) == 10 || str[i].charCodeAt(0) == 13)
	 {
	    out += str[i];
     	 }
	 else if (addSpace)
	 {
	    out += ' ';
	 }
	 addSpace = 0;
      }
   }
   return out;
}


function upd()
{
   if (IsUnchanged(document.encoder.text) *
       IsUnchanged(document.encoder.encdec))
   {
      window.setTimeout('upd()', 100);
      return;
   }
   
   ResizeTextArea(document.encoder.text);

   var e = document.getElementById('output');
 
   if (document.encoder.text.value == '')
   {
      e.innerHTML = 'Hasil';
   }
   else if (document.encoder.encdec.value * 1 == 1)
   {
      e.innerHTML = HTMLEscape(encode(document.encoder.text.value));
   }
   else
   {
      e.innerHTML = HTMLEscape(decode(document.encoder.text.value));
   }
   
   window.setTimeout('upd()', 100);
}



function start_update()
{
   if (! document.getElementById)
   {
      alert('Pakai browser versi terbaru');
      return;
   }

   if ((! document.Util_Loaded) ||
       (! document.getElementById('output')))
   {
      window.setTimeout('start_update()', 100);
      return;
   }
   upd();
}

function SetMorse(m)
{
   document.encoder.encdec.value = "-1";
   document.encoder.text.value = m;
   return false;
}


window.setTimeout('start_update()', 100);
</script>

<script language="JavaScript">
function Trim(s)
{
   while (s.length && " \t\r\n".indexOf(s.charAt(0)) >= 0)
   {
      s = s.slice(1, s.length);
   }
   while (s.length && " \t\r\n".indexOf(s.charAt(s.length - 1)) >= 0)
   {
      s = s.slice(0, s.length - 1);
   }

   return s;
}
function Tr(s, f, t)
{
   var o = '';

   if (typeof(t) != 'string')
   {
      t = '';
   }

   for (var i = 0; i < s.length; i ++)
   {
      var c = s.charAt(i);
      var idx = f.indexOf(c);
      if (idx >= 0)
      {
         if (idx < t.length)
	 {
            o += t.charAt(idx);
	 }
      }
      else
      {
         o += c;
      }
   }

   return o;
}
function InsertCRLF(t, e)
{
   var o = "", i, j;

   for (i = 0, j = 0; i < t.length; i ++)
   {
      if ("\r\n".indexOf(t.charAt(i)) >= 0)
      {
         o += t.charAt(i);
      }
      else
      {
         o += e.charAt(j ++);
      }
   }

   return o;
}
function MakeKeyedAlphabet(key, alphabet)
{
   var out = "";

   if (typeof(alphabet) != 'string')
      alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
   else
      alphabet = alphabet.toUpperCase();

   if (typeof(key) != 'string')
      return alphabet;

   key = key.toUpperCase() + alphabet;
   for (var i = 0; i < key.length; i ++)
   {
      if (out.indexOf(key.charAt(i)) < 0 &&
          alphabet.indexOf(key.charAt(i)) >= 0)
      {
         out += key.charAt(i);
      }
   }

   return out;
}
function OnlyAlpha(str)
{
   var out = "";

   for (i = 0; i < str.length; i ++)
   {
      var b = str.charAt(i);
      if (b.toUpperCase() >= 'A' && b.toUpperCase() <= 'Z')
      {
         out += b;
      }
   }

   return out;
}

function HTMLEscape(str)
{
   var out = "";

   for (var i = 0; i < str.length; i ++)
   {
      var c = str.charAt(i);
      if (c == '&')
         c = '&amp;';
      if (c == '>')
         c = '&gt;';
      if (c == '<')
         c = '&lt;';
      if (c == "\n")
         c = "<br>\n";
      out += c;
   }

   return out;
}
function ResizeTextArea(obj)
{
   var s = obj.value + "\n";
   var newlines = 0;
   var max_chars = 0;
   var i, chars = 0, wide = 0;
   var obj_max_cols = 100, obj_min_cols = 40, obj_max_rows = 15;
   var scrollbar_width = 2;

   for (i = 0; i < s.length; i ++)
   {
      var c = s.charAt(i);
      if (c == "\n")
      {
         if (max_chars < chars)
	    max_chars = chars;
	 chars = 0;
	 newlines ++;
      }
      else
      {
         if (chars == obj_max_cols - scrollbar_width)
         {
	    max_chars = chars;
            j = i;
	    var c2 = s.charAt(j);
	    while (c2 != "\n" && c2 != ' ' && c2 != "\t" && j > 0)
	    {
	       j --;
	       c2 = s.charAt(j);
	    }
	    if (c2 != "\n" && j > 0)
	    {
	       newlines ++;
	       chars = 0;
	       i = j;
	    }
	    else
	    {
	       wide = 1;
	    }
         }
         else
         {
            chars ++;
         }
      }
      if (obj_max_rows <= newlines + wide + 1 &&
         obj_max_cols <= max_chars + scrollbar_width)
      {
         obj.rows = obj_max_rows;
	 obj.cols = obj_max_cols;
	 return;
      }
   }

   obj.rows = Math.min(obj_max_rows, newlines + wide + 1);
   obj.cols = Math.min(Math.max(obj_min_cols, max_chars + scrollbar_width), obj_max_cols);
}


function Reverse_String(s)
{
   var o = '', i = s.length;

   while (i --)
   {
      o += s.charAt(i);
   }

   return o;
}
function IsUnchanged(e)
{
   var v;

   if (e.type == 'checkbox')
   {
      v = e.checked.toString();
   }
   else
   {
      v = e.value;
   }

   if (v != e.getAttribute('_oldValue'))
   {
      e.setAttribute('_oldValue', v);
      return 0;
   }

   return 1;
}

function HTMLTableau(key)
{
   var out = '';

   for (var i = 0; i < 25; i ++)
   {
      if (i > 0 && i % 5 == 0)
      {
         out += "<br>\n";
      }
      if (i % 5)
      {
         out += " ";
      }
      out += key.charAt(i);
   }

   return "<tt>" + out + "</tt>";
}
function SwapSpaces(in_str)
{
    return in_str.replace(/\n /g, '\n&nbsp;')
        .replace(/ \n/g, '&nbsp;\n')
        .replace(/\r /g, '\r&nbsp;')
        .replace(/ \r/g, '&nbsp;\r')
        .replace(/\t /g, '\t&nbsp;')
        .replace(/ \t/g, '&nbsp;\t')
        .replace(/^ /g, '&nbsp;')
        .replace(/ $/g, '&nbsp;')
        .replace(/  /g, ' &nbsp;');
}
var LetterFrequency_LastText = '';
var LetterFrequency_LastFreq = new Array();
function LetterFrequency(text)
{
   var n = new Array();
   var i = 0, j;

   if (LetterFrequency_LastText == text)
   {
      return LetterFrequency_LastFreq;
   }

   if (text.slice(0, LetterFrequency_LastText.length) ==
       LetterFrequency_LastText)
   {
      n = LetterFrequency_LastFreq;
      i = LetterFrequency_LastText.length;
   }

   for (j = text.length; i < j; i ++)
   {
      var c = text.charAt(i);
      if (! n[c])
      {
         n[c] = 1;
      }
      else
      {
         n[c] ++;
      }
   }

   LetterFrequency_LastText = text;
   LetterFrequency_LastFreq = n;

   return n;
}
var PrimeList = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47,
   53, 59, 61, 67, 71, 73, 79, 83, 89, 97];
function IsPrime(n)
{
   if (n < 2 || n != Math.floor(n)) {
      return false;
   }

   for (var i = 0; i < PrimeList.length; i ++) {
      if (PrimeList[i] == n) {
         return true;
      }
      if (PrimeList[i] > n) {
         return false;
      }
   }

   var m = Math.floor(Math.sqrt(n));
   var m2 = PrimeList[PrimeList.length - 1];
   if (m2 < m) {
      while (m2 <= m) {
	 m2 += 2;
         if (IsPrime(m2)) {
	    PrimeList[PrimeList.length] = m2;
	 }
      }
   }

   for (var i = 0; PrimeList[i] <= m; i ++) {
      var d = n / PrimeList[i];
      if (d == Math.floor(d)) {
         return false;
      }
   }

   return true;
}

function GetFactors(n)
{
   var factors = new Array();
   if (n < 1 || n != Math.floor(n))
   {
      return factors;
   }

   if (IsPrime(n)) {
      factors[factors.length] = n;
      return factors;
   }

   var index = 0;
   var skipCheck = 0;
   while (skipCheck || ! IsPrime(n)) {
      var d = n / PrimeList[index];
      if (d == Math.floor(d)) {
         if (PrimeList[index] != factors[factors.length - 1]) {
	    factors[factors.length] = PrimeList[index];
	 }
	 n = d;
	 skipCheck = 0;
      } else {
         index ++;
	 skipCheck = 1;
      }
   }
   if (n != factors[factors.length - 1]) {
      factors[factors.length] = n;
   }

   return factors;
}

var CoprimeCache = new Array();
var CoprimeCacheNum = new Array();
function IsCoprime(a, b)
{
   var a_factors = false, b_factors = false;

   if (a < 1 || b < 1 || a != Math.floor(a) || b != Math.floor(b)) {
      return false;
   }
   if (a == 1 || b == 1) {
      return true;
   }

   for (var i = 0; i < CoprimeCacheNum.length; i ++) {
      if (CoprimeCacheNum[i] == a) {
         a_factors = CoprimeCache[i];
      }
      if (CoprimeCacheNum[i] == b) {
         b_factors = CoprimeCache[i];
      }
   }

   if (! a_factors) {
      a_factors = GetFactors(a);
   }
   if (! b_factors) {
      b_factors = GetFactors(b);
   }
   CoprimeCache = [a_factors, b_factors];
   CoprimeCacheNum = [a, b];

   var a_idx = 0;
   var b_idx = 0;
   while (a_idx < a_factors.length && b_idx < b_factors.length)
   {
      if (a_factors[a_idx] < b_factors[b_idx]) {
         a_idx ++;
      } else if (a_factors[a_idx] > b_factors[b_idx]) {
         b_idx ++;
      } else {
         return false;
      }
   }
   return true;
}


document.Util_Loaded = 1;
</script>