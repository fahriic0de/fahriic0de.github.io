<?php
@ini_set('output_buffering',0); 
@ini_set('display_errors', 0);
$text = $_POST['code'];
?>
<?php
$judul=@Ip_Geolocation;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<div class="table">
<table class="table table-bordered table-striped">
    <thead>
<?php
error_reporting(0);
$host = $_REQUEST['host'];
$ua = array('http' => array('user_agent' => 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.8.0.3) Gecko/20060522 Firefox/1.5.0.3'));
$context  = stream_context_create($ua);
$content = file_get_contents("http://ip-api.com/json/$host", false, $context);
$match = preg_match_all("/success/",$content,$count);
?>
<p>Insert IP/Domain:</p><br>
<form action="<?php $_PHP_SELF; ?>" method="POST">
<input type="text" class="form-control text-primary" autocomplete="off" name="host" size="30" value="<?php if ( $host ) { echo $host; } ?>" placeholder="google.com / 216.58.201.238" /><br>
	<br>
  <center>
<input type="submit" class="btn btn-outline-warning" value="Check" />
</form>
</center>
<br>
<?php
if(trim($host))
{
if($match)
{
$data = json_decode( $content, true);
echo '<br>';
echo '<div class="table table-responsive">
<thead class="thead-light">
<tr class="text-danger">';
echo '<tr><td><b>IP</b></td><td><b>:</b></td><td>' . $data['query'] .'</td></tr>';
echo '<tr><td><b>ASN</b></td><td><b>:</b></td><td>' . $data['as'] .'</td></tr>';
echo '<tr><td><b>Country</b></td><td><b>:</b></td><td>' . $data['country'] .'</td></tr>';
echo '<tr><td><b>Country Code</b></td><td><b>:</b></td><td>' . $data['countryCode'] .'</td></tr>';
echo '<tr><td><b>States</b></td><td><b>:</b></td><td>' . $data['regionName'] .'</td></tr>';
echo '<tr><td><b>State code</b></td><td><b>:</b></td><td>' . $data['region'] .'</td></tr>';
echo '<tr><td><b>City</b></td><td><b>:</b></td><td>' . $data['city'] .'</td></tr>';
echo '<tr><td><b>Postal code</b></td><td><b>:</b></td><td>' . $data['zip'] .'</td></tr>';
echo '<tr><td><b>Time zone</b></td><td><b>:</b></td><td>' . $data['timezone'] .'</td></tr>';
echo '<tr><td><b>Service provider</b></td><td><b>:</b></td><td>' . $data['isp'] .'</td></tr>';
echo '<tr><td><b>Company</b></td><td><b>:</b></td><td>' . $data['org'] .'</td></tr>';
echo '<tr><td><b>Latlong coordinates</b></td><td><b>:</b></td><td>' . $data['lat'] . ', ' . $data['lon'] .'</td></tr>';
echo '<tr><td><b><a href="http://www.google.com/maps/place/' . $data['lat'] . ',' . $data['lon'] .'/@' . $data['lat'] . ',' . $data['lon'] . ',16z" target="_blank">Google Maps</a></b></td></tr>';
}
else
{
echo 'Result:<br><div class="error">/!\ Failed<br>Host Not Valid <b>' . htmlspecialchars($host) . '</b></div>';
}
}
?>
	</table>
</div>