<br>
<div class="row">
          <div class="col-12 col-xl-12 grid-margin stretch-card">
            <div class="card overflow-hidden">
              <div class="card-body">
                  <strong>Advertisement</strong>
                  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"
     crossorigin="anonymous"></script>
<script>
   (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-4502758583657884",
          enable_page_level_ads: true,
          overlay: {bottom: true}
     });
     </script>
            </div>
          </div>
        </div>
        </div>
</div>

<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
				<p class="text-muted text-center text-md-left">Copyright © 2022 <a href="https://www.hotelpromotecodes.com/tools/" target="_blank">Fahri.XD</a></script> <img src="https://i.imgur.com/Imsbaxc.gif" width="18px">. All rights reserved</p>
				<p class="text-muted text-center text-md-left mb-0 d-none d-md-block">Made With <i class="mb-1 text-primary ml-1 icon-small" data-feather="heart"></i> Fahri.XD</p>
			</footer>
		</div>
	</div>

	<!-- core:js -->
	<script src="assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="assets/vendors/chartjs/Chart.min.js"></script>
  <script src="assets/vendors/jquery.flot/jquery.flot.js"></script>
  <script src="assets/vendors/jquery.flot/jquery.flot.resize.js"></script>
  <script src="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="assets/vendors/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendors/progressbar.js/progressbar.min.js"></script>
  <script src="assets/vendors/sweetalert2/sweetalert2.all.min.js"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/template.js"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
  <script src="assets/js/dashboard.js"></script>
  <script src="assets/js/datepicker.js"></script>
	<!-- end custom js for this page -->
</body>
<script src="https://www.google.com/recaptcha/api.js"></script>
<div id="recaptcha" class="g-recaptcha"
          data-sitekey="6LcGG60hAAAAABhy5f0ojDpqvCGcVEZGa4K2o_Mw"
          data-callback="onSubmit"
          data-size="invisible"></div>
</html>    