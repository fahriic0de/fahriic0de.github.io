<div class="alert alert-icon-primary" role="alert">
	<i data-feather="alert-circle"></i>
	Welcome Tools Fahri.XD Support Us With Donate
</div>