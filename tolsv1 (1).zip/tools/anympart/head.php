<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="Online Web Tools">
  <meta name="keywords" content="Tools Online, Web Tools, Hacking Tools, Free Tools, Free Online Tools, Programmer Tools, Pentester Tools,">
  <meta name="author" content="Fahri.XD, A2-TEAM">
  <meta property="og:description" content="Online Web Tools" />
    <link href='https://k.top4top.io/p_24725yyp40.jpeg' rel='icon' type='image/x-icon'/>
    <link rel="favicon" type="image/png" href="https://k.top4top.io/p_24725yyp40.jpeg" />
    <meta property="og:image" content="https://k.top4top.io/p_24725yyp40.jpeg">
<meta name="robots" content="index,follow" />
<meta name="googlebot" content="index,follow" />
	<title>Online Tools - Fahri.XD</title>
	<!-- core:css -->
	<link rel="stylesheet" href="assets/vendors/core/core.css">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
	<!-- endinject -->
	<!-- SWEET ALERT -->
	<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>
	<!-- end ya de -->
  <!-- Layout styles -->  
	<link rel="stylesheet" href="assets/css/demo_1/style.css">
  <!-- End layout styles -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css">
  <link rel="shortcut icon" href="https://k.top4top.io/p_24725yyp40.jpeg" />
  </head>
<script>
window.addEventListener("scroll",scrollPrinsh);
function scrollPrinsh(){
var winScroll=document.body.scrollTop||document.documentElement.scrollTop;
var height=document.documentElement.scrollHeight-document.documentElement.clientHeight;
var scrolled=(winScroll/height)*100;
document.getElementById("scrollbar-NPrinsh").style.width=scrolled+"%";
}
</script>
<style>
.NPrinsh-progress-bar{
background:linear-gradient(90deg,#ff0005 10%,#d81fef 90%);
opacity:.95;
position:fixed;
top:0;
left:0;
height:3px;
z-index:999;
transition:all .4s cubic-bezier(.47,1.64,.41,.8);
}
</style>
<div class="NPrinsh-progress-bar" id="scrollbar-NPrinsh"></div>
<body>
	<div class="main-wrapper">