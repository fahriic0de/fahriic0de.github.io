<!--Network Tools-->

<li class="nav-item">
  <a class="nav-link" data-toggle="collapse" href="#Network" role="button" aria-expanded="false" aria-controls="Network">
    <i class="link-icon" data-feather="radio"></i>
    <span class="link-title">Network</span>
    <i class="link-arrow" data-feather="chevron-down"></i>
  </a>
  <div class="collapse" id="Network">
    <ul class="nav sub-menu">
      <li class="nav-item">
        <a href="ipadres.php" class="nav-link">IP Adrees</a>
      </li>
      <li class="nav-item">
        <a href="Dirrrrrr-Search.php" class="nav-link">Directory Seacrh</a>
      </li>
      <li class="nav-item">
        <a href="dns.php" class="nav-link">DNS LookUp</a>
      </li>
      <li class="nav-item">
        <a href="domain.php" class="nav-link">Domain Checker</a>
      </li>
      <li class="nav-item">
        <a href="DomaintoIP.php" class="nav-link">Domain To IP</a>
      </li>
      <li class="nav-item">
        <a href="ipgeo.php" class="nav-link">IP Geolocation</a>
      </li>      
      <li class="nav-item">
        <a href="pagecheck.php" class="nav-link">Page Checker</a>
      </li>      
      <li class="nav-item">
        <a href="revdns.php" class="nav-link">Reverse DNS</a>
      </li>     
      <li class="nav-item">
        <a href="revip.php" class="nav-link">Reverse IP</a>
      </li>  
      <li class="nav-item">
        <a href="subdofind2.php" class="nav-link">Sub Domain Finder</a>
      </li>  
      <li class="nav-item">
        <a href="whois.php" class="nav-link">Whois LookUp</a>
      </li>
      <li class="nav-item">
        <a href="bwatranslator.php" class="nav-link">Bwa Translator</a>
      </li>
    </ul>
  </div>
</li>

<!--Network Tools End-->


<!--Programmer Tools-->

<li class="nav-item">
  <a class="nav-link" data-toggle="collapse" href="#Programmer" role="button" aria-expanded="false" aria-controls="Programmer">
    <i class="link-icon" data-feather="code"></i>
    <span class="link-title">Programmer</span>
    <i class="link-arrow" data-feather="chevron-down"></i>
  </a>
  <div class="collapse" id="Programmer">
    <ul class="nav sub-menu">
      <li class="nav-item">
        <a href="Charcode.php" class="nav-link">Text To Charcode</a>
      </li>
      <li class="nav-item">
        <a href="hashgen.php" class="nav-link">Hash Generator</a>
      </li>
      <li class="nav-item">
        <a href="hashgen2.php" class="nav-link">Hash Generator 2</a>
      </li>
      <li class="nav-item">
        <a href="hashiden.php" class="nav-link">Hash Identifier</a>
      </li>
      <li class="nav-item">
        <a href="html_escape.php" class="nav-link">Html Escape</a>
      </li>
      <li class="nav-item">
        <a href="livecoding.php" class="nav-link">Live Coding</a>
      </li>
      <li class="nav-item">
        <a href="obfuscate.php" class="nav-link">PHP Obfuscator</a>
      </li>
      <li class="nav-item">
        <a href="adfin.php" class="nav-link">Admin Finder</a>
      </li>
    </ul>
  </div>
</li>

<!--Programmer Tools End-->

<!--Pentester Tools-->

<li class="nav-item">
  <a class="nav-link" data-toggle="collapse" href="#Pentester" role="button" aria-expanded="false" aria-controls="Pentester">
    <i class="link-icon" data-feather="terminal"></i>
    <span class="link-title">Pentester</span>
    <i class="link-arrow" data-feather="chevron-down"></i>
  </a>
  <div class="collapse" id="Pentester">
    <ul class="nav sub-menu">
      <li class="nav-item">
        <a href="akp.php" class="nav-link">AKP AFU</a>
      </li>
      <li class="nav-item">
        <a href="Balitbang-SQLI.php" class="nav-link">Balitbang SQLI</a>
      </li>
      <li class="nav-item">
        <a href="cbt.php" class="nav-link">CBT Scan</a>
      </li>
      <li class="nav-item">
        <a href="crack-passwordbalibang.php" class="nav-link">Crack Password Balitbang</a>
      </li>
      <li class="nav-item">
        <a href="click.php" class="nav-link">ClickJacking</a>
      </li>
      <li class="nav-item">
        <a href="CMS-IAD.php" class="nav-link">CMS IAD Xploit</a>
      </li>
      <li class="nav-item">
        <a href="cms-scan.php" class="nav-link">CMS Scanner</a>
      </li>
      <li class="nav-item">
        <a href="CMS_SekolahkuSqli.php" class="nav-link">CMS Sekolahku Xploit</a>
      </li>      
      <li class="nav-item">
        <a href="csrf.php" class="nav-link">CSRF</a>
      </li> 
      <li class="nav-item">
        <a href="ddos.php" class="nav-link">Ddos Online</a>
      </li>       
      <li class="nav-item">
        <a href="drupal-xploit.php" class="nav-link">Drupal Xploit</a>
      </li> 
      <li class="nav-item">
        <a href="E-Sakip.php" class="nav-link">E-Sakip Xploit</a>
      </li> 
      <li class="nav-item">
        <a href="jso.php" class="nav-link">JSO Generator</a>
      </li>
    <li class="nav-item">
        <a href="jss.php" class="nav-link">Joomla Server Scan</a>
      </li> 
    <li class="nav-item">
        <a href="PHP-Unit.php" class="nav-link">Laravel PHP Unit</a>
      </li> 
      <li class="nav-item">
        <a href="ojs.php" class="nav-link">OJS Shell Finder</a>
      </li>
      <li class="nav-item">
        <a href="port.php" class="nav-link">Port Scan</a>
      </li>
      <li class="nav-item">
        <a href="SchoolHost-Auto-Xploit.php" class="nav-link">SchoolHost Xploit</a>
      </li> 
      <li class="nav-item">
        <a href="sqli.php" class="nav-link">Sql Injection Lib</a>
      </li> 
      <li class="nav-item">
        <a href="Shell-Check.php" class="nav-link">Shell Checker</a>
      </li> 
      <li class="nav-item">
        <a href="Shell-Finder.php" class="nav-link">Shell Finder</a>
      </li> 
      <li class="nav-item">
        <a href="timthumb.php" class="nav-link">TimThumb Xploit</a>
      <li class="nav-item">
        <a href="tim.php" class="nav-link">TimThumb RCE</a>
      </li> 
      <li class="nav-item">
        <a href="xamppauto.php" class="nav-link">XAMPP Xploit</a>
      </li> 
<li class="nav-item">
        <a href="zoneh.php" class="nav-link">Zone-H Notifier</a>
      </li> 
    </ul>
  </div>
</li>

<!--Pentester Tools End-->

<!--Checker Tools-->

<li class="nav-item">
  <a class="nav-link" data-toggle="collapse" href="#Checker" role="button" aria-expanded="false" aria-controls="Checker">
    <i class="link-icon" data-feather="credit-card"></i>
    <span class="link-title">Checker</span>
    <i class="link-arrow" data-feather="chevron-down"></i>
  </a>
  <div class="collapse" id="Checker">
    <ul class="nav sub-menu">
      <li class="nav-item">
        <a href="amazon.php" class="nav-link">Amazon</a>
      </li>
      <li class="nav-item">
        <a href="paypal.php" class="nav-link">Paypal</a>
      </li>
    </ul>
  </div>
</li>

<!--Checker Tools End-->

<!--Encryption Tools-->

<li class="nav-item">
  <a class="nav-link" data-toggle="collapse" href="#Encryption" role="button" aria-expanded="false" aria-controls="Encryption">
    <i class="link-icon" data-feather="key"></i>
    <span class="link-title">Encryption</span>
    <i class="link-arrow" data-feather="chevron-down"></i>
  </a>
  <div class="collapse" id="Encryption">
    <ul class="nav sub-menu">
      <li class="nav-item">
        <a href="base32d.php" class="nav-link">Base32 Decode</a>
      </li>
      <li class="nav-item">
        <a href="base32e.php" class="nav-link">Base32 Encode</a>
      </li>
      <li class="nav-item">
        <a href="endec2.php" class="nav-link">Encode Decode</a>
      </li>
      <li class="nav-item">
        <a href="html_en1.php" class="nav-link">HTML Encrypt</a>
      </li>
      <li class="nav-item">
        <a href="img.php" class="nav-link">Image Encode</a>
      </li>
      <li class="nav-item">
        <a href="ROT13.php" class="nav-link">ROT13</a>
      </li>
      <li class="nav-item">
        <a href="SHA.php" class="nav-link">SHA Encode</a>
      </li>
      <li class="nav-item">
        <a href="shorten.php" class="nav-link">Shorten</a>
        </li>
      <li class="nav-item">
        <a href="shorten2.php" class="nav-link">Shorten V2</a>
        </li>
    </ul>
  </div>
</li>

<!--Encryption Tools-->

<!--Other Tools-->

<li class="nav-item">
  <a class="nav-link" data-toggle="collapse" href="#other" role="button" aria-expanded="false" aria-controls="other">
    <i class="link-icon" data-feather="codesandbox"></i>
    <span class="link-title">Other</span>
    <i class="link-arrow" data-feather="chevron-down"></i>
  </a>
  <div class="collapse" id="other">
    <ul class="nav sub-menu">
    <li class="nav-item">
        <a href="botnulis.php" class="nav-link">BOT Nulis</a>
      </li>
      <li class="nav-item">
        <a href="Efek-Dopler.php" class="nav-link">Efek Dopler</a>
      </li>
      <li class="nav-item">
        <a href="EK.php" class="nav-link">Energi Kinetik</a>
      </li>
      <li class="nav-item">
        <a href="EP.php" class="nav-link">Energi Potensial</a>
      </li>
      <li class="nav-item">
        <a href="shalat.php" class="nav-link">Jadwal Shalat</a>
      </li>
      <li class="nav-item">
        <a href="jetshot.php" class="nav-link">Jeet Shot</a>
      </li>
      <li class="nav-item">
        <a href="gdrive.php" class="nav-link">Google Drive Direct</a>
      </li>
      <li class="nav-item">
        <a href="Github.php" class="nav-link">Github Downloader</a>
      </li>
      <li class="nav-item">
        <a href="GLBB.php" class="nav-link">GLBB</a>
      </li>
      <li class="nav-item">
        <a href="cek-ongkr.php" class="nav-link">Cek Ongkir</a>
      </li>
      <li class="nav-item">
        <a href="Hukum-Newton-II.php" class="nav-link">Hukum Newton 2</a>
      </li>
      <li class="nav-item">
        <a href="img-resizer.php" class="nav-link">Image Resizer</a>
      </li>
      <li class="nav-item">
        <a href="Link-Scraper.php" class="nav-link">Link Scrapper</a>
      </li>
      <li class="nav-item">
        <a href="meta-tag-gen.php" class="nav-link">Meta Tag Generator</a>
      </li>
      <li class="nav-item">
        <a href="momentum.php" class="nav-link">Momentum</a>
      </li>
      <li class="nav-item">
        <a href="morse.php" class="nav-link">Morse Code</a>
      </li>
      <li class="nav-item">
        <a href="pingpong.php" class="nav-link">Ping Pong</a>
      </li>
      <li class="nav-item">
        <a href="percepatan-sudut.php" class="nav-link">Percepatan Sudut</a>
      </li>
      <li class="nav-item">
        <a href="qr2.php" class="nav-link">QR Code Generator</a>
      </li>
      <li class="nav-item">
        <a href="Random-Password-Generator.php" class="nav-link">Random Password</a>
      </li>
      <li class="nav-item">
        <a href="dino.php" class="nav-link">Dino</a>
      </li>
      <li class="nav-item">
        <a href="snake.php" class="nav-link">Snake</a>
      </li>
      <li class="nav-item">
        <a href="Track.php" class="nav-link">Tracking Paket</a>
      </li>
      <li class="nav-item">
        <a href="down.php" class="nav-link">Video Downloader</a>
      </li>
    </ul>
  </div>
</li>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4502758583657884"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-4502758583657884"
     data-ad-slot="5401596108"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
<!--Other Tools end-->