<?php
$judul=@Live_Coding;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
      <center>
				    		<table>
				    			<link href="https://fonts.googleapis.com/css?family=Rock Salt|Righteous" rel="stylesheet">
				    			<style>
				    				#result{
				    				resize:none;
				    				width:500px;
				    				height:500px;
				    			}
				    			h1{
				    				font-size: 40px;
				    			}
				    			iframe{
				    				background-color: white;
				    				color: black;
				    				resize: none;
				    				font-family: 'Teko',sans-serif;
				    				width: 500px;
				    				height: 500px;
				    			}
				    			textarea{
				    				width: 500px;
				    				height: 500px;
				    				color: black;
				    			}
				    		</style>
				    		<center>
				    			<br>
				    			<div class="card-body">
				    				<textarea rows="8" id="TextEditor" onkeyup="RunCode()" autofocus="autofocus">
				    				</textarea>
				    			</div>
				    			<br><hr color="white">
				    			<div class="container">
				    				<div class="row">
				    				</div>
				    				<br><lable>Output</lable><br><br><iframe id="result"></iframe>
				    			</div>
				    		</div>
				    		</center>
				    		</table>
				    	</center>
				    </div>
				</div>
				</div>
			</div>
		</div>
	</div>
	<script>
		function RunCode() {
			var CodeText = document.getElementById('TextEditor').value;
			document.getElementById('result').srcdoc = CodeText;
		}
	</script>