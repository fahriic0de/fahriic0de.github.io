<?php 
include'anympart/head.php'?>
<?php 
include'anympart/sidebar.php' 
?>
<?php 
include'datatools/Charcode.php' 
?>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include'anympart/footer.php' ?>