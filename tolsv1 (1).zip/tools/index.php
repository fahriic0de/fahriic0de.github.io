<?php 
include'anympart/head.php'?>
<?php 
include'anympart/sidebar.php' 
?>
<div class="alert alert-icon-info" role="alert">
	<i data-feather="alert-circle"></i>
	welcome to tools fahri.xd</div>

<div class="row">
          <div class="col-12 col-xl-12 grid-margin stretch-card">
            <div class="card overflow-hidden">
              <div class="card-body">
                  <strong>Information</strong>
                <center>
                    <img src="https://k.top4top.io/p_24725yyp40.jpeg" height="55%" width="55%">
                    <br>
                    <br>
                    <p>Terima kasih telah berkunjung di situs Fahri.XD
Gunakan tools dengan bijak ya.dan yang paling penting jangan merusak situs ini.</p>
                    <br><p>Arigato gozaimasu!</p>
                    <br>
                    <audio controls="true">
                    <source src="https://l.top4top.io/m_2472i67ej0.mp3">
                    </audio>
                    <br>
                    <button type="button" class="btn btn-outline-primary" onclick="window.location.href='https://www.fahri-xd.xyz'"><i data-feather="book-open"></i>Blog Me</button>
                    <button type="button" class="btn btn-outline-warning" onclick="window.location.href='https://www.facebook.com/Allboutattacker-Team-106563198768769'"><i data-feather="server"></i>Fanpage A2-TEAM</button>
                    <button type="button" class="btn btn-outline-info" onclick="window.location.href='https://www.facebook.com/fahry.id.31'"><i data-feather="copy"></i>Faceebook</button>
                    <button type="button" class="btn btn-outline-danger" onclick="window.location.href='#'"><i data-feather="youtube"></i>Youtube</button>
                </center>

            </div>
          </div>
        </div>
</div>

<div class="card text-white bg-primary">
    <div class="card-header">Note <span class="badge badge-info">Update</span></div>
    <div class="card-body">
                
<p>Web masih dalam tahap pengembangan_^</p><br>

Whatsapp : +62895320091720<br>
Email : fm599043@gmail.com<br>
instgram : fahristrss<br>
    </div>
  </div>
  <br>
<br>
<?php include'anympart/footer.php' ?>