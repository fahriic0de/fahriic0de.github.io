<?php
$judul=@Shorten_URL;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<center>          
<form action="" method="post">
    <br>
    <label>Link</label>
	<input type="text" name="url" class="form-control">
	<br>
	<input type="submit" name="submit" class="btn btn-outline-warning" value="Shorten">
</form>

<?php
if (isset($_POST['submit'])) {
	$url1 = urlencode($_POST['url']);
	$url  = urlencode("https://semawur.com/st/?api=f3fa14e4904ecd72d4114976be0d88779a5ed7eb&url=$url1");
	$key = "9d63e3e0ec1f3ff6719b1fdd6fd70610ebd90";
	$json = file_get_contents("https://cutt.ly/api/api.php?key=$key&short=$url");
	$data = json_decode($json, true);
	if($data['url']['status'] == "2") {
	echo "<br><div class='alert alert-danger> Yang Lo Masukkin Bukan Link Goblok,Heker Tolol </div>";
	}
	elseif($data['url']['status'] == "3") {
		echo "<br><div class='alert alert-warning> Link Nya Sudah Ada </div>";
	}
	elseif($data['url']['status'] == "5") {
		echo "<br><div class='alert alert-danger> Karakter Tidak Valid </div>";
	}
	elseif($data['url']['status'] == "6") {
		echo "<br><div class='alert alert-danger> Domain Diblokir </div>";
	}
	else{
		$result = $data['url']['shortLink'];
		echo"<br><div class='alert alert-success'> <a id='HelixUwU' href=$result> $result </a></div>";
		}
	}

?>
</center>