<?php
$judul=@Shorten_URL_V2;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<center> 
<form action="" method="post">
    <br>
    <label>Link</label>
	<input type="text" name="url" class="form-control">
	<br>
	<input type="submit" name="submit" class="btn btn-outline-warning" value="Shorten">
</form>
<?php

if (isset($_POST['submit'])) {
 
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 
function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
 
    return $random_string;
}

$alias = generate_string($permitted_chars, 10); //ganti angka sesuai jumlah yang kamu mau
$url = urlencode($_POST['url']);
$api_token = '88d7c82f44c33e5ad941f581a11820d9f201f9ad'; //DEVELOPER API 
$api_url = "https://od-checker.com/api?api=$api_token&url=$url&alias=$alias";
$result = @json_decode(file_get_contents($api_url),TRUE);
if($result["status"] === 'error') {
echo '<br><div class="alert alert-danger"> Error '. $result["message"] .'</div>';
} else {
echo "<br><div class='alert alert-success'> <a href=". $result['shortenedUrl'] ." >". $result['shortenedUrl'] ."</a></div>";
}

}
?>
</center>