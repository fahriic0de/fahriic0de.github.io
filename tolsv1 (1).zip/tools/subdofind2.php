<?php
$judul=@Subdomain_Finder_API_HackerTarget;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
<form action='' method='POST'>
<center>
<input type='text' name='url' class="form-control text-primary" placeholder="helixs.my.id">
</center>
<br>
<center><input type='submit' name='go' value="Go" class="btn btn-outline-primary">
</center>
<br>


</form>
   <?php
    if(isset($_POST['go'])){
$url       =$_POST['url'];
$url  = str_replace("https://", "", $url);
$url  = str_replace("http://", "", $url);
$url  = str_replace("/", "", $url);
$url  = str_replace("www.", "", $url);
$urlhasil  = "https://api.hackertarget.com/hostsearch/?q=" . $url;
$result    = file_get_contents($urlhasil);
$result  = str_replace(",", "", $result);
$result  = str_replace("1", "", $result);
$result  = str_replace("2", "", $result);
$result  = str_replace("3", "", $result);
$result  = str_replace("4", "", $result);
$result  = str_replace("5", "", $result);
$result  = str_replace("6", "", $result);
$result  = str_replace("7", "", $result);
$result  = str_replace("8", "", $result);
$result  = str_replace("9", "", $result);
$result  = str_replace("0", "", $result);
echo'<center>
<textarea name="subdo" class="form-control text-danger" cols="auto" rows="45">';
echo $result;
echo'</textarea>
</center>';
    ?>

    <?php } ?>